/**
 * UI Manager for Ganesha — The Festival Guardian
 * Renders glassmorphic festival HUD, dialogue cards, shopping marketplace,
 * Vighna meter, rhythm circle, stage celebrations, and final scorecard.
 */
import { audioSystem } from "./audio.js";

export class UIManager {
    constructor() {
        this.scoreEl = document.getElementById("hud-score");
        this.chandaEl = document.getElementById("hud-chanda");
        this.stageNameEl = document.getElementById("hud-stage-name");
        this.stageNumEl = document.getElementById("hud-stage-num");
        this.objectiveEl = document.getElementById("hud-objective");
        this.progressEl = document.getElementById("hud-progress");
        this.interactionPrompt = document.getElementById("interaction-prompt");
        this.modalContainer = document.getElementById("modal-overlay");
    }

    updateHUD({ stageNum, stageName, objective, score, chanda, progress }) {
        if (this.stageNumEl && stageNum !== undefined) this.stageNumEl.textContent = `STAGE 0${stageNum}`;
        if (this.stageNameEl && stageName !== undefined) this.stageNameEl.textContent = stageName;
        if (this.objectiveEl && objective !== undefined) this.objectiveEl.textContent = objective;
        if (this.scoreEl && score !== undefined) this.scoreEl.textContent = score;
        if (this.chandaEl && chanda !== undefined) this.chandaEl.textContent = `₹${chanda}`;
        if (this.progressEl && progress !== undefined) this.progressEl.textContent = progress;
    }

    showPrompt(text) {
        if (!this.interactionPrompt) return;
        this.interactionPrompt.innerHTML = `<span>E</span> ${text}`;
        this.interactionPrompt.classList.remove("hidden");
    }

    hidePrompt() {
        if (!this.interactionPrompt) return;
        this.interactionPrompt.classList.add("hidden");
    }

    showFloatingBadge(text, color = "#ffd166") {
        const badge = document.createElement("div");
        badge.className = "floating-badge";
        badge.style.color = color;
        badge.textContent = text;
        document.body.appendChild(badge);

        setTimeout(() => {
            badge.remove();
        }, 1400);
    }

    clearModal() {
        if (this.modalContainer) {
            this.modalContainer.innerHTML = "";
            this.modalContainer.classList.add("hidden");
        }
    }

    /**
     * Show Devotee Dialogue Card (Stage 1)
     */
    showDevoteeDialogue(devotee, onCollect, onClose) {
        if (!this.modalContainer) return;
        audioSystem.playClick();

        this.modalContainer.innerHTML = `
            <div class="festival-card dialogue-card">
                <div class="card-header">
                    <span class="icon">🙏</span>
                    <div>
                        <h2>${devotee.name}</h2>
                        <span class="role">${devotee.role || "Devotee"}</span>
                    </div>
                </div>

                <p class="devotee-quote">"${devotee.dialogue}"</p>

                <div class="trust-container">
                    <div class="trust-label">
                        <span>Devotee Trust</span>
                        <strong>${devotee.trust}%</strong>
                    </div>
                    <div class="trust-bar-bg">
                        <div class="trust-bar-fill" style="width: ${devotee.trust}%"></div>
                    </div>
                </div>

                <div class="donation-highlight">
                    <span>Offering for Ganesha</span>
                    <strong class="donation-amt">₹${devotee.donation}</strong>
                </div>

                <div class="btn-group">
                    <button id="btn-collect" class="btn-primary">
                        🪙 COLLECT ₹${devotee.donation}
                    </button>
                    <button id="btn-cancel" class="btn-secondary">
                        NOT NOW
                    </button>
                </div>
            </div>
        `;

        this.modalContainer.classList.remove("hidden");

        document.getElementById("btn-collect").onclick = () => {
            audioSystem.playCoinSound();
            this.clearModal();
            if (onCollect) onCollect();
        };

        document.getElementById("btn-cancel").onclick = () => {
            audioSystem.playClick();
            this.clearModal();
            if (onClose) onClose();
        };
    }

    /**
     * Show Festival Shopping Modal (Stage 2)
     */
    showShoppingModal(shops, budget, spent, inventory, onPurchase, onClose) {
        if (!this.modalContainer) return;

        const remaining = budget - spent;

        const shopItemsHTML = shops.map((shop) => {
            const isBought = inventory.includes(shop.id);
            const canAfford = remaining >= shop.price;
            return `
                <div class="shop-stall ${isBought ? 'bought' : ''}">
                    <div class="stall-emoji">${shop.emoji}</div>
                    <div class="stall-info">
                        <h3>${shop.name}</h3>
                        <p>${shop.desc}</p>
                        <span class="price-tag">₹${shop.price}</span>
                    </div>
                    <div>
                        ${isBought 
                            ? `<span class="badge-purchased">✓ PURCHASED</span>`
                            : `<button class="btn-buy" data-id="${shop.id}" ${!canAfford ? 'disabled' : ''}>
                                ${canAfford ? 'BUY' : 'NO FUNDS'}
                               </button>`
                        }
                    </div>
                </div>
            `;
        }).join("");

        this.modalContainer.innerHTML = `
            <div class="festival-card market-card">
                <div class="card-header">
                    <span class="icon">🛍️</span>
                    <div>
                        <h2>Festival Marketplace</h2>
                        <span class="role">Purchase sacred items for Ganesha Puja</span>
                    </div>
                </div>

                <div class="budget-tracker">
                    <div class="b-item">
                        <span>Chanda Budget</span>
                        <strong>₹${budget}</strong>
                    </div>
                    <div class="b-item">
                        <span>Spent</span>
                        <strong class="spent">₹${spent}</strong>
                    </div>
                    <div class="b-item">
                        <span>Remaining</span>
                        <strong class="remaining">₹${remaining}</strong>
                    </div>
                </div>

                <div class="shops-grid">
                    ${shopItemsHTML}
                </div>

                <div class="market-footer">
                    <div class="checklist-summary">
                        <span>Checklist: ${inventory.length} / ${shops.length} Bought</span>
                    </div>
                    <button id="btn-close-market" class="btn-primary">
                        ${inventory.length === shops.length ? 'FINISH SHOPPING' : 'CONTINUE MARKET'}
                    </button>
                </div>
            </div>
        `;

        this.modalContainer.classList.remove("hidden");

        // Wire purchase buttons
        const buyButtons = this.modalContainer.querySelectorAll(".btn-buy");
        buyButtons.forEach(btn => {
            btn.onclick = (e) => {
                const id = e.target.getAttribute("data-id");
                if (onPurchase) onPurchase(id);
            };
        });

        document.getElementById("btn-close-market").onclick = () => {
            audioSystem.playClick();
            this.clearModal();
            if (onClose) onClose();
        };
    }

    /**
     * Show Stage Completion Modal
     */
    showStageComplete({ stageNum, stageTitle, description, stats, nextStageTitle, onNext }) {
        if (!this.modalContainer) return;
        audioSystem.playTempleBell(1.1);

        const statsHTML = stats.map(s => `
            <div class="stat-row">
                <span>${s.label}</span>
                <strong>${s.value}</strong>
            </div>
        `).join("");

        this.modalContainer.innerHTML = `
            <div class="festival-card stage-complete-card">
                <div class="celebration-symbol">🪔</div>
                <div class="stage-tag">STAGE 0${stageNum} COMPLETE</div>
                <h1>${stageTitle}</h1>
                <p class="congrats-text">${description}</p>

                <div class="stats-summary">
                    ${statsHTML}
                </div>

                <div class="next-preview">
                    <span>UP NEXT</span>
                    <strong>${nextStageTitle}</strong>
                </div>

                <button id="btn-next-stage" class="btn-primary btn-large">
                    CONTINUE ADVENTURE ▶
                </button>
            </div>
        `;

        this.modalContainer.classList.remove("hidden");

        document.getElementById("btn-next-stage").onclick = () => {
            audioSystem.playClick();
            this.clearModal();
            if (onNext) onNext();
        };
    }

    /**
     * Show Final Grand Celebration Scorecard
     */
    showFinalCelebration({ scoreBreakdown, totalScore, rank, onPlayAgain, onMainMenu }) {
        if (!this.modalContainer) return;
        audioSystem.playConchCall();

        const rowsHTML = scoreBreakdown.map(r => `
            <div class="score-line">
                <span>${r.stage}</span>
                <strong>+${r.score}</strong>
            </div>
        `).join("");

        this.modalContainer.innerHTML = `
            <div class="festival-card grand-finale-card">
                <div class="celebration-symbol">🐘</div>
                <div class="stage-tag">GANESH CHATURTHI GRAND FINALE</div>
                <h1>THE FESTIVAL IS COMPLETE</h1>
                <p class="congrats-text">
                    With your devotion and guardianship as Mushika, the Ganesh Chaturthi celebration 
                    was carried out with pure harmony and supreme joy!
                </p>

                <div class="scorecard-box">
                    <h3>FINAL FESTIVAL SCORE</h3>
                    <div class="score-lines">
                        ${rowsHTML}
                    </div>
                    <div class="total-score-row">
                        <span>TOTAL FESTIVAL SCORE</span>
                        <strong>${totalScore}</strong>
                    </div>
                    <div class="rank-badge">
                        <span>AWARDED TITLE</span>
                        <h2>${rank}</h2>
                    </div>
                </div>

                <div class="btn-group">
                    <button id="btn-play-again" class="btn-primary btn-large">
                        🔄 PLAY AGAIN
                    </button>
                    <button id="btn-main-menu" class="btn-secondary btn-large">
                        🏠 MAIN MENU
                    </button>
                </div>
            </div>
        `;

        this.modalContainer.classList.remove("hidden");

        document.getElementById("btn-play-again").onclick = () => {
            audioSystem.playClick();
            this.clearModal();
            if (onPlayAgain) onPlayAgain();
        };

        document.getElementById("btn-main-menu").onclick = () => {
            audioSystem.playClick();
            this.clearModal();
            if (onMainMenu) onMainMenu();
        };
    }
}
