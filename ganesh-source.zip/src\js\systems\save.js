/**
 * Save System for Ganesha — The Festival Guardian
 * Persists game progress, high score, and festival items to localStorage.
 */

const STORAGE_KEY = "ganesha_festival_guardian_save_v1";

export class SaveSystem {
    constructor() {
        this.data = this.load();
    }

    getDefaults() {
        return {
            stage: 1,
            score: 0,
            chanda: 0,
            devoteesHelped: 0,
            inventory: [],
            highestScore: 0,
            completedAllStages: false
        };
    }

    load() {
        try {
            const raw = localStorage.getItem(STORAGE_KEY);
            if (raw) {
                return { ...this.getDefaults(), ...JSON.parse(raw) };
            }
        } catch (e) {
            console.warn("Could not load saved game state", e);
        }
        return this.getDefaults();
    }

    save(updates = {}) {
        this.data = { ...this.data, ...updates };
        try {
            localStorage.setItem(STORAGE_KEY, JSON.stringify(this.data));
        } catch (e) {
            console.warn("Could not persist game state", e);
        }
    }

    reset() {
        this.data = this.getDefaults();
        try {
            localStorage.removeItem(STORAGE_KEY);
        } catch (e) {}
    }
}

export const saveSystem = new SaveSystem();
