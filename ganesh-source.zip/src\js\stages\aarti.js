/**
 * Stage 6: Interactive Aarti Ceremony
 * Player performs the sacred circular Aarti offering around Lord Ganesha:
 * Aarti thali with flickering camphor flame, rhythmic timing rings to devotional bells,
 * flower petal showers, and chanting neighborhood crowd.
 */
import * as THREE from "three";
import { gameState } from "../gameState.js";
import { audioSystem } from "../systems/audio.js";

export class AartiCeremonyStage {
    constructor(game) {
        this.game = game;
        this.world = game.world;
        this.camera = game.camera;
        this.ui = game.ui;
        this.particles = game.particles;
        this.aartiThali = null;
        this.aartiAngle = 0;
        this.beatsCompleted = 0;
        this.targetBeats = 12;
        this.isRhythmActive = false;
        this.beatInterval = null;
    }

    start() {
        this.beatsCompleted = 0;
        this.updateHUD();
        this.buildAartiThali();
        this.startAartiRhythm();

        audioSystem.playTempleBell(1.1);
        audioSystem.startAmbient();
    }

    updateHUD() {
        this.ui.updateHUD({
            stageNum: 6,
            stageName: "AARTI CEREMONY",
            objective: "Perform circular Aarti offering with devotion (Press Space / E / Click on Beat).",
            score: gameState.score,
            chanda: gameState.chanda,
            progress: `Aarti Harmony: ${this.beatsCompleted} / ${this.targetBeats}`
        });
    }

    buildAartiThali() {
        const thaliGroup = new THREE.Group();

        // 1. Ornate Brass Plate
        const plate = new THREE.Mesh(
            new THREE.CylinderGeometry(0.75, 0.68, 0.08, 24),
            new THREE.MeshStandardMaterial({
                color: 0xefa020,
                metalness: 0.9,
                roughness: 0.2
            })
        );
        thaliGroup.add(plate);

        // 2. Camphor (Karpuram) Deepam Center with glowing flame
        const deepam = new THREE.Mesh(
            new THREE.CylinderGeometry(0.2, 0.12, 0.14, 14),
            new THREE.MeshStandardMaterial({ color: 0xcc5500 })
        );
        deepam.position.y = 0.08;
        thaliGroup.add(deepam);

        const flame = new THREE.Mesh(
            new THREE.ConeGeometry(0.12, 0.35, 12),
            new THREE.MeshStandardMaterial({
                color: 0xffffff,
                emissive: 0xff9900,
                emissiveIntensity: 5.5
            })
        );
        flame.position.y = 0.32;
        thaliGroup.add(flame);

        // Camphor Light source
        const camphorLight = new THREE.PointLight(0xffa033, 3.5, 6.0);
        camphorLight.position.y = 0.5;
        thaliGroup.add(camphorLight);

        // 3. Flower petals around thali border
        for (let i = 0; i < 8; i++) {
            const angle = (i / 8) * Math.PI * 2;
            const p = new THREE.Mesh(
                new THREE.SphereGeometry(0.08, 8, 8),
                new THREE.MeshStandardMaterial({ color: i % 2 === 0 ? 0xd90429 : 0xffc300 })
            );
            p.position.set(Math.cos(angle) * 0.52, 0.06, Math.sin(angle) * 0.52);
            thaliGroup.add(p);
        }

        thaliGroup.position.set(0, 2.6, -2.5);
        this.game.scene.add(thaliGroup);
        this.aartiThali = thaliGroup;
    }

    startAartiRhythm() {
        this.isRhythmActive = true;

        // Traditional Aarti musical notes: "Jai Ganesh Jai Ganesh Deva"
        const aartiMelodyNotes = [
            440, 440, 493.88, 554.37, 587.33, 659.25, 587.33, 554.37,
            493.88, 440, 440, 493.88, 554.37, 440
        ];

        let noteIdx = 0;
        this.beatInterval = setInterval(() => {
            if (!this.isRhythmActive) return;

            // Play procedural aarti melodic note and drum pulse
            const note = aartiMelodyNotes[noteIdx % aartiMelodyNotes.length];
            audioSystem.playAartiNote(note, 0.45);
            audioSystem.playDholakBeat(noteIdx % 2 === 0 ? "bass" : "snap");
            noteIdx++;

            // Visual rhythm pulse
            this.showRhythmPrompt();
        }, 800);
    }

    showRhythmPrompt() {
        // Subtle floating prompt
        this.ui.showPrompt("🪔 OFFER AARTI (Space / E / Click)");
    }

    update(time, delta) {
        // Rotate Aarti thali in sacred circular motion (clockwise / pradakshina) in front of Ganesha
        if (this.aartiThali) {
            this.aartiAngle += delta * 1.5;
            const radiusX = 1.4;
            const radiusY = 0.6;
            this.aartiThali.position.x = Math.cos(this.aartiAngle) * radiusX;
            this.aartiThali.position.y = 2.4 + Math.sin(this.aartiAngle) * radiusY;
            this.aartiThali.position.z = -2.5 + Math.sin(this.aartiAngle) * 0.3;
        }

        // Camera gentle swaying
        this.camera.position.x = Math.sin(time * 0.5) * 0.4;
    }

    handleInteraction() {
        if (!this.isRhythmActive) return;

        this.beatsCompleted++;
        gameState.addScore(30);

        audioSystem.playTempleBell(1.1 + (this.beatsCompleted % 4) * 0.08);
        this.particles.burstSparkles(this.aartiThali.position.x, this.aartiThali.position.y + 0.4, this.aartiThali.position.z, 25);
        this.ui.showFloatingBadge("✨ Jai Ganesh Deva! (+30)", "#ffe066");

        this.updateHUD();

        if (this.beatsCompleted >= this.targetBeats) {
            this.isRhythmActive = false;
            clearInterval(this.beatInterval);
            setTimeout(() => {
                this.finishStage();
            }, 1000);
        }
    }

    finishStage() {
        if (this.aartiThali) {
            this.game.scene.remove(this.aartiThali);
        }
        audioSystem.stopAmbient();

        this.ui.showStageComplete({
            stageNum: 6,
            stageTitle: "AARTI CEREMONY COMPLETE",
            description: "With heartfelt devotion, you led the grand Aarti for Lord Ganesha. The glowing camphor flame illuminated the sanctum as the entire neighborhood joined in blissful harmony!",
            stats: [
                { label: "Aarti Rhythms Completed", value: `${this.targetBeats} Circles of Light` },
                { label: "Community Devotion", value: "100% Blissful" },
                { label: "Festival Seva Score", value: `+${gameState.score}` }
            ],
            nextStageTitle: "Final: Grand Festival Celebration",
            onNext: () => {
                this.cleanup();
                this.game.startStage(7);
            }
        });
    }

    cleanup() {
        this.ui.hidePrompt();
        if (this.beatInterval) clearInterval(this.beatInterval);
    }
}
