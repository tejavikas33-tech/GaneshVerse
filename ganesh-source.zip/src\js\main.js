/**
 * Application Entry Point
 * Ganesha — The Festival Guardian
 * GANESHVERSE Studio
 */
import { FestivalGame } from "./game.js";
import { audioSystem } from "./systems/audio.js";

window.addEventListener("DOMContentLoaded", () => {
    const canvas = document.getElementById("game-canvas");
    const loadingScreen = document.getElementById("loading-screen");
    const gameUI = document.getElementById("game-ui");
    const gameHUD = document.getElementById("game-hud");
    const controlHint = document.getElementById("control-hint");
    const playButton = document.getElementById("play-button");
    const howButton = document.getElementById("how-button");

    // Initialize Game engine
    const game = new FestivalGame(canvas);

    // Hide loading screen after assets buffer
    setTimeout(() => {
        if (loadingScreen) {
            loadingScreen.classList.add("hidden");
        }
    }, 1000);

    // Start Festival Button
    if (playButton) {
        playButton.onclick = () => {
            audioSystem.init();
            audioSystem.playTempleBell(1.0);

            gameUI.classList.add("hidden");
            gameHUD.classList.remove("hidden");
            controlHint.classList.remove("hidden");

            game.start();
        };
    }

    // How to Play Modal
    if (howButton) {
        howButton.onclick = () => {
            audioSystem.init();
            audioSystem.playClick();

            alert(
                "🪔 GANESHA — THE FESTIVAL GUARDIAN\n\n" +
                "CONTROLS:\n" +
                "• WASD / Arrow Keys → Move Mushika 🐭\n" +
                "• E / Mouse Click → Interact with doors, residents, and sacred items\n" +
                "• Spacebar / Click → Perform Aarti on beat\n\n" +
                "YOUR MISSION:\n" +
                "1. CHANDA YATRA: Walk house-to-house, collect Chanda funds & materials, invite at least 8 families.\n" +
                "2. MURTI SEARCH: Visit Shree Ganesh Kalakendra workshop and choose the festival idol.\n" +
                "3. ARRIVAL: Help welcome Lord Ganesha with conch shells, flowers, and illumination.\n" +
                "4. PANDAL PREPARATION: Decorate the pandal using collected resources.\n" +
                "5. PUJA: Perform the sacred offerings alongside the returning neighborhood families!\n" +
                "6. AARTI: Offer the light of the camphor flame to 'Jai Ganesh Deva'.\n" +
                "7. GRAND CELEBRATION: Rejoice in the magnificent fireworks and complete celebration!"
            );
        };
    }
});