/**
 * Stage 1: Chanda Yatra — House to House
 * Player walks through the neighborhood, knocks on doors, greets diverse residents,
 * collects donations (Chanda money, flowers, fruits, coconuts, diyas), and invites
 * families to the evening Ganesh Puja and Aarti.
 */
import { gameState } from "../gameState.js";
import { audioSystem } from "../systems/audio.js";

export class ChandaYatraStage {
    constructor(game) {
        this.game = game;
        this.world = game.world;
        this.ui = game.ui;
        this.particles = game.particles;
        this.nearbyHouse = null;
        this.visitedCount = 0;
        this.targetCount = 8;
    }

    start() {
        this.visitedCount = 0;
        this.updateHUD();
        audioSystem.playTempleBell(0.9);
    }

    updateHUD() {
        this.ui.updateHUD({
            stageNum: 1,
            stageName: "CHANDA YATRA — HOUSE TO HOUSE",
            objective: `Visit neighborhood houses, collect Chanda & invite at least ${this.targetCount} families.`,
            score: gameState.score,
            chanda: gameState.chanda,
            progress: `Invited: ${gameState.invitedFamilies.length} / ${this.targetCount}`
        });
    }

    update(time, delta) {
        const playerPos = this.game.player.position;
        let closest = null;
        let closestDist = 3.5;

        this.world.houses.forEach((house) => {
            if (house.userData.visited) return;

            const dist = playerPos.distanceTo(house.userData.doorPosition);
            if (dist < closestDist) {
                closestDist = dist;
                closest = house;
            }
        });

        if (closest !== this.nearbyHouse) {
            this.nearbyHouse = closest;
            if (this.nearbyHouse) {
                const def = this.nearbyHouse.userData.def;
                this.ui.showPrompt(`Knock on ${def.family}'s Door (E / Click)`);
            } else {
                this.ui.hidePrompt();
            }
        }
    }

    handleInteraction(clickedObj) {
        let house = this.nearbyHouse;
        if (clickedObj && clickedObj.userData && clickedObj.userData.def) {
            house = clickedObj;
        }

        if (!house || house.userData.visited) return;

        const def = house.userData.def;
        this.openHouseDialogue(house, def);
    }

    openHouseDialogue(house, def) {
        audioSystem.playClick();

        let donationSummary = `🪙 ₹${def.amount} Chanda`;
        if (def.flowers) donationSummary += `, 🌺 ${def.flowers} Fresh Flowers`;
        if (def.fruits) donationSummary += `, 🍌 ${def.fruits} Sacred Fruits`;
        if (def.coconuts) donationSummary += `, 🥥 ${def.coconuts} Auspicious Coconuts`;
        if (def.diyas) donationSummary += `, 🪔 ${def.diyas} Clay Diyas`;

        this.ui.modalContainer.innerHTML = `
            <div class="festival-card dialogue-card">
                <div class="card-header">
                    <span class="icon">🏡</span>
                    <div>
                        <h2>${def.family}</h2>
                        <span class="role">${def.role}</span>
                    </div>
                </div>

                <p class="devotee-quote">"${def.dialogue}"</p>

                <div class="donation-highlight">
                    <span>Offering for Lord Ganesha:</span>
                    <strong class="donation-amt">${donationSummary}</strong>
                </div>

                <div class="invitation-box">
                    <span>🪔 "You and your family are warmly invited to the Ganesh Puja & Aarti!"</span>
                </div>

                <div class="btn-group">
                    <button id="btn-accept-donation" class="btn-primary">
                        🙏 ACCEPT & INVITE FAMILY
                    </button>
                    <button id="btn-decline-donation" class="btn-secondary">
                        NOT NOW
                    </button>
                </div>
            </div>
        `;

        this.ui.modalContainer.classList.remove("hidden");

        document.getElementById("btn-accept-donation").onclick = () => {
            this.ui.clearModal();
            this.collectFromHouse(house, def);
        };

        document.getElementById("btn-decline-donation").onclick = () => {
            audioSystem.playClick();
            this.ui.clearModal();
        };
    }

    collectFromHouse(house, def) {
        house.userData.visited = true;
        if (house.userData.marker) {
            house.remove(house.userData.marker);
        }

        // Update Game State
        gameState.addChanda(def.amount);
        if (def.flowers) gameState.addMaterial("flowers", def.flowers);
        if (def.fruits) gameState.addMaterial("fruits", def.fruits);
        if (def.coconuts) gameState.addMaterial("coconuts", def.coconuts);
        if (def.diyas) gameState.addMaterial("diyas", def.diyas);

        gameState.inviteFamily({
            id: def.id,
            name: def.resident,
            family: def.family,
            role: def.role,
            amount: def.amount
        });

        this.visitedCount++;

        // Effects
        audioSystem.playCoinSound();
        this.particles.burstSparkles(house.position.x, 2.0, house.position.z, 25);
        this.ui.showFloatingBadge(`+₹${def.amount} & Invited ${def.resident}!`, "#ffd166");

        this.updateHUD();
        this.ui.hidePrompt();
        this.nearbyHouse = null;

        // Target reached
        if (gameState.invitedFamilies.length >= this.targetCount) {
            setTimeout(() => {
                this.finishStage();
            }, 900);
        }
    }

    finishStage() {
        this.ui.showStageComplete({
            stageNum: 1,
            stageTitle: "CHANDA YATRA COMPLETE",
            description: `Mushika completed the neighborhood procession! With great warmth, you united ${gameState.invitedFamilies.length} families, collected ₹${gameState.chanda} Chanda, and gathered sacred offerings for Lord Ganesha.`,
            stats: [
                { label: "Families Invited", value: `${gameState.invitedFamilies.length} Families` },
                { label: "Chanda Treasury", value: `₹${gameState.chanda}` },
                { label: "Sacred Materials", value: `${gameState.materials.flowers + gameState.materials.fruits + gameState.materials.coconuts + gameState.materials.diyas} Offerings` },
                { label: "Community Seva Score", value: `+${gameState.score}` }
            ],
            nextStageTitle: "Stage 2: Ganesha Murti Search",
            onNext: () => {
                this.cleanup();
                this.game.startStage(2);
            }
        });
    }

    cleanup() {
        this.ui.hidePrompt();
    }
}
