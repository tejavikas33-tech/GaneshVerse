/**
 * Stage 5: Ganesh Puja & Devotees Return
 * The invited neighborhood families from Stage 1 arrive at the pandal in devotion!
 * Player participates in a peaceful, respectful 7-step sacred Puja ritual:
 * 1. Light the Akhand Diya 🪔
 * 2. Offer sacred 21 Durva Grass 🌿
 * 3. Offer fresh Red Hibiscus Flowers 🌺
 * 4. Offer Pancha-phala Fruits 🍌
 * 5. Place the sacred Coconut 🥥
 * 6. Offer steamed Modaks 🍬
 * 7. Fold hands & join community prayer 🙏
 */
import * as THREE from "three";
import { gameState } from "../gameState.js";
import { audioSystem } from "../systems/audio.js";

export class GaneshPujaStage {
    constructor(game) {
        this.game = game;
        this.world = game.world;
        this.ui = game.ui;
        this.particles = game.particles;
        this.currentStep = 0;
        this.devoteeArrivalTimer = null;
        this.arrivedDevoteeIndex = 0;
        this.arrivedMeshes = [];

        this.pujaSteps = [
            {
                id: "step_diya",
                name: "Light the Akhand Ghee Diya",
                emoji: "🪔",
                desc: "Kindle the pure flame to dispel darkness and welcome the divine presence.",
                pos: new THREE.Vector3(0, 1.45, -2.6),
                type: "diya"
            },
            {
                id: "step_durva",
                name: "Offer Sacred 21-Blade Durva Grass",
                emoji: "🌿",
                desc: "Lord Ganesha's most beloved green offering, cooling and auspicious.",
                pos: new THREE.Vector3(-1.0, 1.45, -3.2),
                type: "durva"
            },
            {
                id: "step_flowers",
                name: "Offer Fresh Red Hibiscus & Marigolds",
                emoji: "🌺",
                desc: "Lay fragrant fresh flowers at Lord Ganesha's lotus feet.",
                pos: new THREE.Vector3(1.0, 1.45, -3.2),
                type: "flowers"
            },
            {
                id: "step_fruits",
                name: "Arrange Pancha-Phala Fruit Offerings",
                emoji: "🍌",
                desc: "Offer tender bananas, mangoes and pomegranates as naivedya.",
                pos: new THREE.Vector3(0.9, 1.45, -2.5),
                type: "fruits"
            },
            {
                id: "step_coconut",
                name: "Place Consecrated Sriphala Coconut",
                emoji: "🥥",
                desc: "The sacred coconut symbolizing selflessness and divine fruition.",
                pos: new THREE.Vector3(0, 1.45, -3.8),
                type: "coconut"
            },
            {
                id: "step_modaks",
                name: "Offer Golden Plate of 21 Modaks",
                emoji: "🍬",
                desc: "Sweet steamed modaks filled with coconut and jaggery, Bappa's favorite delight.",
                pos: new THREE.Vector3(-0.9, 1.45, -2.5),
                type: "modaks"
            },
            {
                id: "step_prayer",
                name: "Join Hands in Community Sankalp & Prayer",
                emoji: "🙏",
                desc: "Reverently chant 'Om Gam Ganapataye Namaha' with the united neighborhood.",
                pos: new THREE.Vector3(0, 0.4, 0.5),
                type: "prayer"
            }
        ];
    }

    start() {
        this.currentStep = 0;
        this.arrivedDevoteeIndex = 0;

        this.updateHUD();
        this.startDevoteesReturn();
        this.showCurrentStepIndicator();
        audioSystem.playTempleBell(1.0);
    }

    updateHUD() {
        const step = this.pujaSteps[this.currentStep];
        this.ui.updateHUD({
            stageNum: 5,
            stageName: "GANESH PUJA & DEVOTEES RETURN",
            objective: step ? `Step ${this.currentStep + 1}: ${step.name}` : "Puja Complete",
            score: gameState.score,
            chanda: gameState.chanda,
            progress: `Puja Step ${this.currentStep + 1} / ${this.pujaSteps.length}`
        });
    }

    /**
     * Staggered arrival of the invited families from Stage 1!
     */
    startDevoteesReturn() {
        const families = gameState.invitedFamilies;
        if (!families || families.length === 0) return;

        let index = 0;
        this.devoteeArrivalTimer = setInterval(() => {
            if (index < families.length) {
                const fam = families[index];
                this.spawnArrivingDevotee(fam, index);
                this.ui.showFloatingBadge(`✨ ${fam.family} has arrived for Ganesh Puja!`, "#ffe28a");
                audioSystem.playTempleBell(1.0 + (index % 3) * 0.1);
                index++;
            } else {
                clearInterval(this.devoteeArrivalTimer);
            }
        }, 2200);
    }

    spawnArrivingDevotee(family, idx) {
        const group = new THREE.Group();
        const colors = [0x2b59c3, 0xc9184a, 0x38b000, 0x9d4edd, 0xf3c05b, 0xff7b00];

        // Gather in orderly arcs around the courtyard facing Ganesha
        const row = Math.floor(idx / 4);
        const col = (idx % 4) - 1.5;
        const x = col * 2.6;
        const z = 2.8 + row * 2.2;

        const body = new THREE.Mesh(
            new THREE.CylinderGeometry(0.32, 0.45, 1.25, 16),
            new THREE.MeshStandardMaterial({ color: colors[idx % colors.length], roughness: 0.7 })
        );
        body.position.y = 0.62;
        body.castShadow = true;
        group.add(body);

        const head = new THREE.Mesh(
            new THREE.SphereGeometry(0.26, 16, 16),
            new THREE.MeshStandardMaterial({ color: 0xcc8e66, roughness: 0.8 })
        );
        head.position.y = 1.38;
        group.add(head);

        // Name tag / Floating family indicator
        const canvas = document.createElement("canvas");
        canvas.width = 256; canvas.height = 64;
        const ctx = canvas.getContext("2d");
        ctx.fillStyle = "rgba(10,5,8,0.75)";
        ctx.fillRect(0, 0, 256, 64);
        ctx.strokeStyle = "#e8b65b";
        ctx.strokeRect(2, 2, 252, 60);
        ctx.fillStyle = "#ffe28a";
        ctx.font = "bold 24px sans-serif";
        ctx.textAlign = "center";
        ctx.textBaseline = "middle";
        ctx.fillText(family.name, 128, 34);

        const tex = new THREE.CanvasTexture(canvas);
        const nameMesh = new THREE.Mesh(
            new THREE.PlaneGeometry(1.4, 0.35),
            new THREE.MeshBasicMaterial({ map: tex, side: THREE.DoubleSide })
        );
        nameMesh.position.y = 2.1;
        group.add(nameMesh);

        group.position.set(x, 0, z);
        group.lookAt(0, 1.5, -4.5);

        this.game.scene.add(group);
        this.arrivedMeshes.push(group);
        gameState.arrivedDevotees.push(family);
    }

    showCurrentStepIndicator() {
        if (this.currentStepMarker) {
            this.game.scene.remove(this.currentStepMarker);
            this.currentStepMarker = null;
        }

        if (this.currentStep >= this.pujaSteps.length) return;

        const step = this.pujaSteps[this.currentStep];
        const group = new THREE.Group();

        // Glowing golden marker disc
        const ring = new THREE.Mesh(
            new THREE.RingGeometry(0.35, 0.55, 20).rotateX(-Math.PI / 2),
            new THREE.MeshBasicMaterial({ color: 0xffd166, side: THREE.DoubleSide })
        );
        ring.position.y = 0.05;
        group.add(ring);

        // Floating step emoji
        const canvas = document.createElement("canvas");
        canvas.width = 64; canvas.height = 64;
        const ctx = canvas.getContext("2d");
        ctx.font = "40px sans-serif";
        ctx.textAlign = "center";
        ctx.textBaseline = "middle";
        ctx.fillText(step.emoji, 32, 36);

        const tex = new THREE.CanvasTexture(canvas);
        const icon = new THREE.Mesh(
            new THREE.PlaneGeometry(0.65, 0.65),
            new THREE.MeshBasicMaterial({ map: tex, transparent: true, side: THREE.DoubleSide })
        );
        icon.position.y = 0.6;
        group.add(icon);

        group.position.copy(step.pos);
        group.userData = { step: step, ring: ring, icon: icon };

        this.game.scene.add(group);
        this.currentStepMarker = group;
    }

    update(time, delta) {
        if (this.currentStepMarker && this.currentStepMarker.userData.icon) {
            this.currentStepMarker.userData.icon.position.y = 0.6 + Math.sin(time * 4) * 0.08;
            this.currentStepMarker.userData.icon.rotation.y = time * 1.5;
        }

        // Proximity check for current step
        if (this.currentStep < this.pujaSteps.length) {
            const step = this.pujaSteps[this.currentStep];
            const dist = this.game.player.position.distanceTo(step.pos);

            if (dist < 3.2) {
                this.ui.showPrompt(`${step.name} (E / Click)`);
                this.isNearStep = true;
            } else {
                if (this.isNearStep) {
                    this.ui.hidePrompt();
                    this.isNearStep = false;
                }
            }
        }
    }

    handleInteraction(clickedObj) {
        if (this.currentStep >= this.pujaSteps.length) return;
        const step = this.pujaSteps[this.currentStep];

        // Execute step
        this.executePujaStep(step);
    }

    executePujaStep(step) {
        this.spawnOfferingItemMesh(step);

        audioSystem.playSnapSound();
        audioSystem.playTempleBell(1.0 + this.currentStep * 0.06);

        this.particles.burstSparkles(step.pos.x, step.pos.y + 0.5, step.pos.z, 30);
        this.ui.showFloatingBadge(`Offered: ${step.name}! (+50)`, "#ffd166");

        gameState.addScore(50);
        this.currentStep++;

        if (this.currentStep < this.pujaSteps.length) {
            this.updateHUD();
            this.showCurrentStepIndicator();
        } else {
            this.finishStage();
        }
    }

    spawnOfferingItemMesh(step) {
        const pos = step.pos;

        if (step.type === "diya") {
            const diya = new THREE.Mesh(
                new THREE.CylinderGeometry(0.2, 0.1, 0.12, 14),
                new THREE.MeshStandardMaterial({ color: 0xcc5500 })
            );
            diya.position.copy(pos);
            const flame = new THREE.Mesh(
                new THREE.ConeGeometry(0.08, 0.22, 10),
                new THREE.MeshStandardMaterial({ color: 0xffffff, emissive: 0xff7700, emissiveIntensity: 5.0 })
            );
            flame.position.set(pos.x, pos.y + 0.16, pos.z);
            this.game.scene.add(diya);
            this.game.scene.add(flame);
        } else if (step.type === "durva") {
            const grassMat = new THREE.MeshStandardMaterial({ color: 0x2d6a4f, roughness: 0.6 });
            for (let i = 0; i < 7; i++) {
                const blade = new THREE.Mesh(new THREE.CylinderGeometry(0.02, 0.02, 0.35, 6), grassMat);
                blade.rotation.set((Math.random() - 0.5) * 0.4, 0, (Math.random() - 0.5) * 0.4);
                blade.position.set(pos.x + (Math.random() - 0.5) * 0.15, pos.y + 0.15, pos.z + (Math.random() - 0.5) * 0.15);
                this.game.scene.add(blade);
            }
        } else if (step.type === "flowers") {
            for (let i = 0; i < 5; i++) {
                const fl = new THREE.Mesh(
                    new THREE.SphereGeometry(0.1, 10, 10),
                    new THREE.MeshStandardMaterial({ color: i % 2 === 0 ? 0xd90429 : 0xffa000 })
                );
                fl.position.set(pos.x + (Math.random() - 0.5) * 0.3, pos.y + 0.1, pos.z + (Math.random() - 0.5) * 0.3);
                this.game.scene.add(fl);
            }
        } else if (step.type === "fruits") {
            const fruit = new THREE.Mesh(
                new THREE.SphereGeometry(0.18, 12, 12),
                new THREE.MeshStandardMaterial({ color: 0xffb703 })
            );
            fruit.position.set(pos.x, pos.y + 0.14, pos.z);
            this.game.scene.add(fruit);
        } else if (step.type === "coconut") {
            const coconut = new THREE.Mesh(
                new THREE.SphereGeometry(0.2, 12, 12),
                new THREE.MeshStandardMaterial({ color: 0x5a2d0c, roughness: 0.9 })
            );
            coconut.position.set(pos.x, pos.y + 0.15, pos.z);
            this.game.scene.add(coconut);
        } else if (step.type === "modaks") {
            const plate = new THREE.Mesh(
                new THREE.CylinderGeometry(0.4, 0.35, 0.05, 18),
                new THREE.MeshStandardMaterial({ color: 0xe5a93c, metalness: 0.8 })
            );
            plate.position.copy(pos);
            this.game.scene.add(plate);

            const modakMat = new THREE.MeshStandardMaterial({ color: 0xfffcf2 });
            for (let i = 0; i < 5; i++) {
                const angle = (i / 5) * Math.PI * 2;
                const m = new THREE.Mesh(new THREE.ConeGeometry(0.08, 0.15, 10), modakMat);
                m.position.set(pos.x + Math.cos(angle) * 0.18, pos.y + 0.1, pos.z + Math.sin(angle) * 0.18);
                this.game.scene.add(m);
            }
        }
    }

    finishStage() {
        if (this.currentStepMarker) {
            this.game.scene.remove(this.currentStepMarker);
        }
        if (this.devoteeArrivalTimer) {
            clearInterval(this.devoteeArrivalTimer);
        }

        this.ui.showStageComplete({
            stageNum: 5,
            stageTitle: "GANESH PUJA CONSECRATED",
            description: `All 7 sacred offerings have been reverently made before Lord Ganesha. The ${gameState.invitedFamilies.length} neighborhood families you personally invited during Chanda Yatra have gathered around the pandal, filling the sacred hall with devotion and joy!`,
            stats: [
                { label: "Puja Rituals Completed", value: "7 / 7 Sacred Offerings" },
                { label: "Families in Attendance", value: `${gameState.invitedFamilies.length} Devotee Families` },
                { label: "Consecration Merit Score", value: `+${gameState.score}` }
            ],
            nextStageTitle: "Stage 6: Grand Aarti Ceremony",
            onNext: () => {
                this.cleanup();
                this.game.startStage(6);
            }
        });
    }

    cleanup() {
        this.ui.hidePrompt();
    }
}
