/**
 * Master Game Controller for Ganesha — The Festival Guardian
 * Coordinates Three.js scene, rendering loop, player movement, camera follow,
 * procedural particles, audio, UI, and stage transitions.
 */
import * as THREE from "three";
import { gameState } from "./gameState.js";
import { FestivalWorld } from "./world.js";
import { MushikaPlayer } from "./player.js";
import { FestivalParticleSystem } from "./systems/particles.js";
import { audioSystem } from "./systems/audio.js";
import { UIManager } from "./systems/ui.js";
import { InteractionManager } from "./interaction.js";

// Stage imports
import { ChandaYatraStage } from "./stages/chanda.js";
import { GaneshaShopStage } from "./stages/ganeshaShop.js";
import { GaneshaArrivalStage } from "./stages/arrival.js";
import { PandalPreparationStage } from "./stages/pandal.js";
import { GaneshPujaStage } from "./stages/puja.js";
import { AartiCeremonyStage } from "./stages/aarti.js";
import { GrandCelebrationStage } from "./stages/celebration.js";

export class FestivalGame {
    constructor(canvas) {
        this.canvas = canvas;
        this.keys = {};
        this.currentStageController = null;
        this.clock = new THREE.Clock();
        this.isRunning = false;

        this.initThree();
        this.initSystems();
        this.initInputListeners();
    }

    initThree() {
        // 1. Scene
        this.scene = new THREE.Scene();
        this.scene.background = new THREE.Color(0x08040d);
        this.scene.fog = new THREE.FogExp2(0x120612, 0.015);

        // 2. Camera
        this.camera = new THREE.PerspectiveCamera(
            52,
            window.innerWidth / window.innerHeight,
            0.1,
            200
        );
        this.camera.position.set(0, 7.5, 12.0);

        // 3. Renderer
        this.renderer = new THREE.WebGLRenderer({
            canvas: this.canvas,
            antialias: true,
            powerPreference: "high-performance"
        });
        this.renderer.setSize(window.innerWidth, window.innerHeight);
        this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
        this.renderer.shadowMap.enabled = true;
        this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    }

    initSystems() {
        this.ui = new UIManager();
        this.particles = new FestivalParticleSystem(this.scene);
        this.world = new FestivalWorld(this.scene);
        this.player = new MushikaPlayer(this.scene);

        // Interaction Manager (Dual: E/Space keyboard + mouse click)
        this.interaction = new InteractionManager(
            this.camera,
            this.canvas,
            (clickedObj) => {
                if (this.currentStageController && this.currentStageController.handleInteraction) {
                    this.currentStageController.handleInteraction(clickedObj);
                }
            }
        );

        // Update interactables list whenever stage changes
        this.updateInteractables();
    }

    updateInteractables() {
        const list = [];
        if (this.world.houses) list.push(...this.world.houses);
        if (this.world.murtiPedestals) list.push(...this.world.murtiPedestals);
        this.interaction.setInteractables(list);
    }

    initInputListeners() {
        window.addEventListener("keydown", (e) => {
            this.keys[e.key.toLowerCase()] = true;
        });

        window.addEventListener("keyup", (e) => {
            this.keys[e.key.toLowerCase()] = false;
        });

        window.addEventListener("resize", () => {
            this.camera.aspect = window.innerWidth / window.innerHeight;
            this.camera.updateProjectionMatrix();
            this.renderer.setSize(window.innerWidth, window.innerHeight);
        });
    }

    startStage(stageNum) {
        if (this.currentStageController && this.currentStageController.cleanup) {
            this.currentStageController.cleanup();
        }

        gameState.stage = stageNum;

        switch (stageNum) {
            case 1:
                this.currentStageController = new ChandaYatraStage(this);
                break;
            case 2:
                this.currentStageController = new GaneshaShopStage(this);
                break;
            case 3:
                this.currentStageController = new GaneshaArrivalStage(this);
                break;
            case 4:
                this.currentStageController = new PandalPreparationStage(this);
                break;
            case 5:
                this.currentStageController = new GaneshPujaStage(this);
                break;
            case 6:
                this.currentStageController = new AartiCeremonyStage(this);
                break;
            case 7:
                this.currentStageController = new GrandCelebrationStage(this);
                break;
            default:
                console.warn(`Stage ${stageNum} not recognized`);
                return;
        }

        this.currentStageController.start();
        this.updateInteractables();
    }

    updateCamera() {
        // Only track player during standard gameplay stages (not during cinematics)
        if (gameState.stage === 3 || gameState.stage === 7) return;

        const targetX = this.player.position.x;
        const targetZ = this.player.position.z + 9.5;
        const targetY = 7.0;

        this.camera.position.x += (targetX - this.camera.position.x) * 0.07;
        this.camera.position.z += (targetZ - this.camera.position.z) * 0.07;
        this.camera.position.y += (targetY - this.camera.position.y) * 0.07;

        this.camera.lookAt(
            this.player.position.x,
            1.2,
            this.player.position.z - 1.5
        );
    }

    start() {
        this.isRunning = true;
        this.startStage(1);
        this.animate();
    }

    animate() {
        requestAnimationFrame(() => this.animate());

        const delta = Math.min(this.clock.getDelta(), 0.1);
        const time = this.clock.getElapsedTime();

        if (this.isRunning) {
            // Player movement
            if (gameState.stage !== 3 && gameState.stage !== 7) {
                this.player.update(this.keys, delta, time);
                this.updateCamera();
            }

            // World updates
            this.world.update(time, delta);

            // Particles updates
            this.particles.update(time, delta);

            // Active Stage controller update
            if (this.currentStageController && this.currentStageController.update) {
                this.currentStageController.update(time, delta);
            }
        }

        this.renderer.render(this.scene, this.camera);
    }
}
