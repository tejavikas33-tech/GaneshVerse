/**
 * Final Stage: Grand Festival Celebration
 * The ultimate spectacle:
 * Camera pulls back to reveal the illuminated pandal, Ganesha enthroned in radiant glory,
 * all invited families gathered in joy, shimmering diyas, falling marigold/rose petals,
 * continuous fireworks exploding in the night sky, and the complete festival scorecard.
 */
import * as THREE from "three";
import gsap from "gsap";
import { gameState } from "../gameState.js";
import { audioSystem } from "../systems/audio.js";

export class GrandCelebrationStage {
    constructor(game) {
        this.game = game;
        this.world = game.world;
        this.camera = game.camera;
        this.ui = game.ui;
        this.particles = game.particles;
        this.fireworkTimer = null;
    }

    start() {
        this.ui.updateHUD({
            stageNum: 7,
            stageName: "GRAND FESTIVAL CELEBRATION",
            objective: "Rejoice in the grand community celebration with Lord Ganesha!",
            score: gameState.score,
            chanda: gameState.chanda,
            progress: "Festival Complete 🌟"
        });

        this.startCelebrationSpectacle();
    }

    startCelebrationSpectacle() {
        // Dramatic camera pull back to wide majestic angle
        gsap.to(this.camera.position, {
            x: 0,
            y: 8.5,
            z: 14.5,
            duration: 4.0,
            ease: "power2.out",
            onUpdate: () => {
                this.camera.lookAt(0, 2.8, -4.5);
            }
        });

        // Golden festival illumination
        gsap.to(this.world.ambient, { intensity: 2.2, duration: 2.0 });
        gsap.to(this.world.altarSpot, { intensity: 8.0, duration: 2.0 });

        audioSystem.playConchCall();

        // Continuous night sky fireworks & crackers
        const colors = [0xffb703, 0xff0054, 0x70e000, 0x00f5d4, 0x9b5de5, 0xffd166];
        let fwCount = 0;

        this.fireworkTimer = setInterval(() => {
            const x = (Math.random() - 0.5) * 24;
            const y = 9.0 + Math.random() * 6.0;
            const z = -6.0 + (Math.random() - 0.5) * 10;
            const color = colors[Math.floor(Math.random() * colors.length)];

            this.particles.createFirework(x, y, z, color);
            audioSystem.playFireworkSound();

            fwCount++;
            if (fwCount === 4) {
                audioSystem.playTempleBell(1.2);
            }
        }, 850);

        // Show comprehensive final celebration scorecard after 3 seconds
        setTimeout(() => {
            this.showFinalScorecard();
        }, 3200);
    }

    showFinalScorecard() {
        const totalMaterials = 
            gameState.materials.flowers + 
            gameState.materials.fruits + 
            gameState.materials.coconuts + 
            gameState.materials.diyas;

        this.ui.showFinalCelebration({
            scoreBreakdown: [
                { stage: "Chanda Yatra Contributions", score: Math.round(gameState.chanda / 5) },
                { stage: "Sacred Materials Donated", score: totalMaterials * 20 },
                { stage: `Neighborhood Families United (${gameState.invitedFamilies.length})`, score: gameState.invitedFamilies.length * 50 },
                { stage: "Ganesha Murti Consecration", score: 150 },
                { stage: "Pandal Preparation & Decor", score: 270 },
                { stage: "Sacred Puja Rituals Completed", score: 350 },
                { stage: "Grand Aarti Harmony", score: 360 }
            ],
            totalScore: gameState.score,
            rank: "SUPREME FESTIVAL GUARDIAN 👑",
            onPlayAgain: () => {
                this.cleanup();
                gameState.reset();
                this.game.startStage(1);
            },
            onMainMenu: () => {
                this.cleanup();
                gameState.reset();
                window.location.reload();
            }
        });
    }

    update(time, delta) {
        // Slow majestic camera orbit
        this.camera.position.x = Math.sin(time * 0.2) * 2.0;
    }

    handleInteraction() {}

    cleanup() {
        if (this.fireworkTimer) {
            clearInterval(this.fireworkTimer);
            this.fireworkTimer = null;
        }
        this.ui.clearModal();
    }
}
