/**
 * Global Game State for Ganesha — The Festival Guardian
 * Manages game progress, collected Chanda, donated puja materials,
 * invited neighborhood families, selected Ganesha idol, and festival seva score.
 */

class GameStateManager {
    constructor() {
        this.reset();
    }

    reset() {
        this.stage = 1;
        this.stageName = "CHANDA YATRA";
        this.score = 0;
        this.chanda = 0;

        // Donated items from neighborhood houses
        this.materials = {
            flowers: 0,
            fruits: 0,
            coconuts: 0,
            diyas: 0,
            modaks: 0
        };

        // List of invited families who will attend Puja and Aarti
        this.invitedFamilies = [];

        // Ganesha Murti selected from workshop
        this.selectedMurti = null;

        // Pandal preparation progress
        this.pandalDecorated = false;
        this.placedItems = [];

        // Devotees who arrived at the pandal
        this.arrivedDevotees = [];

        // Final celebration metrics
        this.harmony = 100;
        this.listeners = [];
    }

    subscribe(listener) {
        this.listeners.push(listener);
    }

    notify() {
        this.listeners.forEach((cb) => cb(this));
    }

    addChanda(amount) {
        this.chanda += amount;
        this.addScore(Math.round(amount / 5));
        this.notify();
    }

    addMaterial(type, count = 1) {
        if (this.materials[type] !== undefined) {
            this.materials[type] += count;
        } else {
            this.materials[type] = count;
        }
        this.addScore(20 * count);
        this.notify();
    }

    inviteFamily(family) {
        if (!this.invitedFamilies.find((f) => f.id === family.id)) {
            this.invitedFamilies.push(family);
            this.addScore(50);
            this.notify();
        }
    }

    addScore(pts) {
        this.score += pts;
        this.notify();
    }

    setMurti(murti) {
        this.selectedMurti = murti;
        this.addScore(100);
        this.notify();
    }

    setStage(stageNum, name) {
        this.stage = stageNum;
        this.stageName = name;
        this.notify();
    }
}

export const gameState = new GameStateManager();
