/**
 * Stage 4: Pandal Preparation
 * Player uses the collected Chanda & materials (flowers, diyas, fabrics)
 * to transform the unfinished pandal into a magnificent, resplendent festival hall.
 */
import * as THREE from "three";
import { gameState } from "../gameState.js";
import { audioSystem } from "../systems/audio.js";

export class PandalPreparationStage {
    constructor(game) {
        this.game = game;
        this.world = game.world;
        this.ui = game.ui;
        this.particles = game.particles;
        this.spots = [];
        this.placedCount = 0;
        this.nearbySpot = null;

        this.decorations = [
            {
                id: "torans",
                name: "Marigold Floral Torans",
                desc: "Festive garlands crafted from donated marigolds across the arches.",
                x: 0,
                y: 5.5,
                z: -0.5,
                type: "toran"
            },
            {
                id: "samai_west",
                name: "West Brass Samai Stand",
                desc: "Grand multi-tier brass oil lamp stand illuminating the sanctum.",
                x: -3.8,
                y: 0.8,
                z: -4.5,
                type: "samai"
            },
            {
                id: "samai_east",
                name: "East Brass Samai Stand",
                desc: "Grand multi-tier brass oil lamp stand illuminating the sanctum.",
                x: 3.8,
                y: 0.8,
                z: -4.5,
                type: "samai"
            },
            {
                id: "fairy_lights",
                name: "Golden Serial Fairy Lights",
                desc: "Festive string lights wrapping the carved pillars and beams.",
                x: 0,
                y: 3.5,
                z: -4.5,
                type: "lights"
            },
            {
                id: "chowki_cushions",
                name: "Royal Velvet Cushions",
                desc: "Embroidered crimson bolsters flanking Ganesha's throne.",
                x: 0,
                y: 1.4,
                z: -4.5,
                type: "cushions"
            },
            {
                id: "incense_stand",
                name: "Sugandhit Agarbatti Stand",
                desc: "Fragrant sandalwood and rose incense filling the air with sanctity.",
                x: -1.8,
                y: 1.4,
                z: -3.8,
                type: "incense"
            }
        ];
    }

    start() {
        this.placedCount = 0;
        this.buildSpots();

        this.ui.updateHUD({
            stageNum: 4,
            stageName: "PANDAL PREPARATION",
            objective: "Approach the glowing sacred spots to place pandal decorations.",
            score: gameState.score,
            chanda: gameState.chanda,
            progress: "0% Decorated"
        });

        audioSystem.playTempleBell(1.0);
    }

    buildSpots() {
        this.decorations.forEach((item) => {
            const group = new THREE.Group();

            const ringGeo = new THREE.RingGeometry(0.5, 0.75, 24).rotateX(-Math.PI / 2);
            const ringMat = new THREE.MeshBasicMaterial({
                color: 0xffb703,
                side: THREE.DoubleSide,
                transparent: true,
                opacity: 0.7
            });
            const ring = new THREE.Mesh(ringGeo, ringMat);
            ring.position.y = 0.05;
            group.add(ring);

            const canvas = document.createElement("canvas");
            canvas.width = 64; canvas.height = 64;
            const ctx = canvas.getContext("2d");
            ctx.fillStyle = "#ffffff";
            ctx.font = "38px sans-serif";
            ctx.textAlign = "center";
            ctx.textBaseline = "middle";
            ctx.fillText("✨", 32, 34);

            const iconTex = new THREE.CanvasTexture(canvas);
            const icon = new THREE.Mesh(
                new THREE.PlaneGeometry(0.65, 0.65),
                new THREE.MeshBasicMaterial({ map: iconTex, transparent: true, side: THREE.DoubleSide })
            );
            icon.position.y = 1.2;
            group.add(icon);

            group.position.set(item.x, 0.8, item.z);
            group.userData = {
                item: item,
                ring: ring,
                icon: icon,
                placed: false
            };

            this.game.scene.add(group);
            this.spots.push(group);
        });
    }

    update(time, delta) {
        const playerPos = this.game.player.position;
        let closest = null;
        let closestDist = 2.8;

        this.spots.forEach((spot) => {
            if (spot.userData.placed) return;

            if (spot.userData.ring) {
                const s = 1.0 + Math.sin(time * 4) * 0.15;
                spot.userData.ring.scale.set(s, s, s);
            }
            if (spot.userData.icon) {
                spot.userData.icon.position.y = 1.2 + Math.sin(time * 3) * 0.15;
                spot.userData.icon.rotation.y = time * 1.5;
            }

            const dist = playerPos.distanceTo(spot.position);
            if (dist < closestDist) {
                closestDist = dist;
                closest = spot;
            }
        });

        if (closest !== this.nearbySpot) {
            this.nearbySpot = closest;
            if (this.nearbySpot) {
                this.ui.showPrompt(`Arrange ${this.nearbySpot.userData.item.name} (E / Click)`);
            } else {
                this.ui.hidePrompt();
            }
        }
    }

    handleInteraction(clickedObj) {
        let spot = this.nearbySpot;
        if (clickedObj && clickedObj.userData && clickedObj.userData.item) {
            spot = clickedObj;
        }

        if (!spot || spot.userData.placed) return;

        const item = spot.userData.item;
        spot.userData.placed = true;
        spot.remove(spot.userData.ring);
        spot.remove(spot.userData.icon);

        const mesh = this.createDecorMesh(item.type);
        spot.add(mesh);

        this.placedCount++;
        gameState.addScore(45);
        gameState.placedItems.push(item.id);

        const percent = Math.round((this.placedCount / this.decorations.length) * 100);

        audioSystem.playSnapSound();
        this.particles.burstSparkles(spot.position.x, 1.8, spot.position.z, 30);
        this.ui.showFloatingBadge(`Arranged: ${item.name}! (+45)`, "#ffd166");

        this.ui.updateHUD({
            score: gameState.score,
            progress: `${percent}% Decorated`
        });

        this.ui.hidePrompt();
        this.nearbySpot = null;

        if (this.placedCount >= this.decorations.length) {
            setTimeout(() => {
                this.finishStage();
            }, 900);
        }
    }

    createDecorMesh(type) {
        const group = new THREE.Group();

        if (type === "samai") {
            const brass = new THREE.MeshStandardMaterial({ color: 0xe5a93c, metalness: 0.85, roughness: 0.2 });
            const stem = new THREE.Mesh(new THREE.CylinderGeometry(0.08, 0.15, 2.2, 16), brass);
            stem.position.y = 1.1;
            stem.castShadow = true;
            group.add(stem);

            const tier1 = new THREE.Mesh(new THREE.CylinderGeometry(0.48, 0.22, 0.12, 18), brass);
            tier1.position.y = 1.6;
            group.add(tier1);

            const flame = new THREE.Mesh(
                new THREE.ConeGeometry(0.09, 0.25, 12),
                new THREE.MeshStandardMaterial({ color: 0xffeedd, emissive: 0xff6600, emissiveIntensity: 4.5 })
            );
            flame.position.y = 2.3;
            group.add(flame);

            const light = new THREE.PointLight(0xff9900, 2.5, 5);
            light.position.y = 2.4;
            group.add(light);
        } else if (type === "toran") {
            for (let i = -3.5; i <= 3.5; i += 0.7) {
                const flower = new THREE.Mesh(
                    new THREE.SphereGeometry(0.22, 12, 12),
                    new THREE.MeshStandardMaterial({
                        color: Math.abs(i) % 1.4 < 0.5 ? 0xff7700 : 0xffc300,
                        roughness: 0.8
                    })
                );
                flower.position.set(i, 4.8 + Math.sin((i / 3.5) * Math.PI) * 0.4, 0);
                group.add(flower);
            }
        } else if (type === "lights") {
            [-6.5, 6.5].forEach((px) => {
                for (let y = 1.0; y <= 6.5; y += 0.8) {
                    const bulb = new THREE.Mesh(
                        new THREE.SphereGeometry(0.12, 10, 10),
                        new THREE.MeshStandardMaterial({
                            color: 0xffe066,
                            emissive: 0xffb703,
                            emissiveIntensity: 3.5
                        })
                    );
                    bulb.position.set(px, y, 0);
                    group.add(bulb);
                }
            });
        } else if (type === "cushions") {
            const cushionMat = new THREE.MeshStandardMaterial({ color: 0x9b111e, roughness: 0.5 });
            const bolsterL = new THREE.Mesh(new THREE.CylinderGeometry(0.22, 0.22, 1.4, 16), cushionMat);
            bolsterL.rotation.z = Math.PI / 2;
            bolsterL.position.set(-1.6, 0.55, 0);
            group.add(bolsterL);

            const bolsterR = new THREE.Mesh(new THREE.CylinderGeometry(0.22, 0.22, 1.4, 16), cushionMat);
            bolsterR.rotation.z = Math.PI / 2;
            bolsterR.position.set(1.6, 0.55, 0);
            group.add(bolsterR);
        } else if (type === "incense") {
            const burner = new THREE.Mesh(
                new THREE.CylinderGeometry(0.2, 0.15, 0.1, 16),
                new THREE.MeshStandardMaterial({ color: 0x8a5a36, roughness: 0.6 })
            );
            burner.position.y = 0.05;
            group.add(burner);

            // 3 Agarbatti sticks with glowing red tips
            for (let i = 0; i < 3; i++) {
                const stick = new THREE.Mesh(
                    new THREE.CylinderGeometry(0.015, 0.015, 0.45, 6),
                    new THREE.MeshStandardMaterial({ color: 0x3d2008 })
                );
                stick.rotation.z = (i - 1) * 0.15;
                stick.position.set((i - 1) * 0.05, 0.25, 0);
                group.add(stick);

                const tip = new THREE.Mesh(
                    new THREE.SphereGeometry(0.02, 6, 6),
                    new THREE.MeshBasicMaterial({ color: 0xff3300 })
                );
                tip.position.set((i - 1) * 0.05, 0.48, 0);
                group.add(tip);
            }
        }

        return group;
    }

    finishStage() {
        this.ui.showStageComplete({
            stageNum: 4,
            stageTitle: "PANDAL PREPARATION COMPLETE",
            description: `Using the community's donations (₹${gameState.chanda} Chanda and sacred offerings), the pandal is transformed with golden torans, glowing brass samai stands, twinkling fairy lights, and fragrant incense.`,
            stats: [
                { label: "Pandal Readiness", value: "100% Prepared" },
                { label: "Decorations Placed", value: "6 Sacred Elements" },
                { label: "Festival Seva Score", value: `+${gameState.score}` }
            ],
            nextStageTitle: "Stage 5: Puja Ritual & Devotees Return",
            onNext: () => {
                this.cleanup();
                this.game.startStage(5);
            }
        });
    }

    cleanup() {
        this.ui.hidePrompt();
    }
}
