/**
 * World & Environment Manager
 * Builds a realistic, immersive Indian festival neighborhood:
 * Central Pandal, realistic houses with unique facades (Tulsi plants, rangoli,
 * porches, tiled roofs, verandas), street lighting, roadside trees, and the
 * Ganesha Murti Workshop.
 */
import * as THREE from "three";
import { GLTFLoader } from "three/addons/loaders/GLTFLoader.js";

export class FestivalWorld {
    constructor(scene) {
        this.scene = scene;
        this.houses = [];
        this.shops = [];
        this.diyas = [];
        this.ganeshaModel = null;
        this.isGaneshaRevealed = false;

        this.initLighting();
        this.buildGroundAndStreets();
        this.buildPandal();
        this.buildNeighborhoodHouses();
        this.buildMurtiWorkshop();
        this.loadGaneshaModel();
    }

    initLighting() {
        // Warm dusk ambient light
        this.ambient = new THREE.AmbientLight(0xffdfb8, 1.6);
        this.scene.add(this.ambient);

        // Directional moonlight with soft shadows
        this.sunMoon = new THREE.DirectionalLight(0xffb570, 2.4);
        this.sunMoon.position.set(12, 18, 10);
        this.sunMoon.castShadow = true;
        this.sunMoon.shadow.mapSize.width = 1024;
        this.sunMoon.shadow.mapSize.height = 1024;
        this.sunMoon.shadow.camera.near = 1;
        this.sunMoon.shadow.camera.far = 50;
        this.sunMoon.shadow.camera.left = -22;
        this.sunMoon.shadow.camera.right = 22;
        this.sunMoon.shadow.camera.top = 22;
        this.sunMoon.shadow.camera.bottom = -22;
        this.scene.add(this.sunMoon);

        // Focal altar spotlight on Ganesha
        this.altarSpot = new THREE.SpotLight(0xffe699, 4.2, 22, Math.PI / 4, 0.35, 1.2);
        this.altarSpot.position.set(0, 9, 2);
        this.altarSpot.target.position.set(0, 2.5, -4.5);
        this.scene.add(this.altarSpot);
        this.scene.add(this.altarSpot.target);
    }

    buildGroundAndStreets() {
        // Main festival ground
        const groundGeo = new THREE.PlaneGeometry(60, 60);
        groundGeo.rotateX(-Math.PI / 2);
        const groundMat = new THREE.MeshStandardMaterial({
            color: 0x3a100a,
            roughness: 0.95
        });
        const ground = new THREE.Mesh(groundGeo, groundMat);
        ground.receiveShadow = true;
        this.scene.add(ground);

        // Cobblestone / paved street paths connecting houses to pandal
        const streetMat = new THREE.MeshStandardMaterial({
            color: 0x542018,
            roughness: 0.85
        });

        // Main central boulevard
        const mainStreet = new THREE.Mesh(new THREE.PlaneGeometry(8, 36).rotateX(-Math.PI / 2), streetMat);
        mainStreet.position.set(0, 0.02, 8);
        mainStreet.receiveShadow = true;
        this.scene.add(mainStreet);

        // Cross street West-East
        const crossStreet = new THREE.Mesh(new THREE.PlaneGeometry(42, 6).rotateX(-Math.PI / 2), streetMat);
        crossStreet.position.set(0, 0.02, 10);
        crossStreet.receiveShadow = true;
        this.scene.add(crossStreet);

        // Grand Lotus Rangoli in front of Pandal entrance
        const rangoliCanvas = document.createElement("canvas");
        rangoliCanvas.width = 512;
        rangoliCanvas.height = 512;
        const ctx = rangoliCanvas.getContext("2d");
        const cx = 256, cy = 256;

        ctx.beginPath();
        ctx.arc(cx, cy, 240, 0, Math.PI * 2);
        ctx.strokeStyle = "#e8b65b";
        ctx.lineWidth = 10;
        ctx.stroke();

        // 16 Lotus petals
        for (let i = 0; i < 16; i++) {
            const angle = (i / 16) * Math.PI * 2;
            ctx.beginPath();
            ctx.arc(cx + Math.cos(angle) * 190, cy + Math.sin(angle) * 190, 26, 0, Math.PI * 2);
            ctx.fillStyle = i % 2 === 0 ? "#ff5400" : "#ffb703";
            ctx.fill();
        }

        ctx.beginPath();
        ctx.arc(cx, cy, 130, 0, Math.PI * 2);
        ctx.fillStyle = "#780000";
        ctx.fill();

        ctx.fillStyle = "#ffe28a";
        ctx.font = "bold 95px serif";
        ctx.textAlign = "center";
        ctx.textBaseline = "middle";
        ctx.fillText("ॐ", cx, cy);

        const rangoliTex = new THREE.CanvasTexture(rangoliCanvas);
        const rangoliMesh = new THREE.Mesh(
            new THREE.CircleGeometry(6.5, 48).rotateX(-Math.PI / 2),
            new THREE.MeshStandardMaterial({ map: rangoliTex, transparent: true, opacity: 0.94 })
        );
        rangoliMesh.position.set(0, 0.04, 2.5);
        rangoliMesh.receiveShadow = true;
        this.scene.add(rangoliMesh);
    }

    buildPandal() {
        const pandal = new THREE.Group();

        // 1. Raised Sacred Platform
        const platform = new THREE.Mesh(
            new THREE.CylinderGeometry(8.5, 9.2, 0.8, 48),
            new THREE.MeshStandardMaterial({ color: 0x6e1b0c, roughness: 0.75 })
        );
        platform.position.set(0, 0.4, -4.5);
        platform.receiveShadow = true;
        pandal.add(platform);

        // Platform golden rim
        const rim = new THREE.Mesh(
            new THREE.TorusGeometry(8.6, 0.14, 16, 48).rotateX(Math.PI / 2),
            new THREE.MeshStandardMaterial({ color: 0xe8b65b, metalness: 0.85, roughness: 0.2 })
        );
        rim.position.set(0, 0.8, -4.5);
        pandal.add(rim);

        // 2. Pillars with carved bases and floral wraps
        const pillarPositions = [
            [-6.5, -8.5],
            [6.5, -8.5],
            [-6.5, -0.5],
            [6.5, -0.5]
        ];

        pillarPositions.forEach(([px, pz]) => {
            const pillar = new THREE.Group();
            const col = new THREE.Mesh(
                new THREE.CylinderGeometry(0.38, 0.45, 7.0, 20),
                new THREE.MeshStandardMaterial({ color: 0x801e0a, roughness: 0.6 })
            );
            col.position.y = 3.9;
            col.castShadow = true;
            pillar.add(col);

            const base = new THREE.Mesh(
                new THREE.CylinderGeometry(0.7, 0.8, 0.7, 16),
                new THREE.MeshStandardMaterial({ color: 0xd69e3d, metalness: 0.6, roughness: 0.3 })
            );
            base.position.y = 0.75;
            pillar.add(base);

            const capital = new THREE.Mesh(
                new THREE.CylinderGeometry(0.8, 0.6, 0.7, 16),
                new THREE.MeshStandardMaterial({ color: 0xd69e3d, metalness: 0.6, roughness: 0.3 })
            );
            capital.position.y = 7.4;
            pillar.add(capital);

            pillar.position.set(px, 0, pz);
            pandal.add(pillar);
        });

        // 3. Pandal Arches and Canopy
        const arch = new THREE.Mesh(
            new THREE.BoxGeometry(13.6, 0.7, 0.9),
            new THREE.MeshStandardMaterial({ color: 0x962813, roughness: 0.6 })
        );
        arch.position.set(0, 7.5, -0.5);
        pandal.add(arch);

        // Hanging Marigold Torans along the entrance
        for (let i = -5.5; i <= 5.5; i += 1.1) {
            const marigold = new THREE.Mesh(
                new THREE.SphereGeometry(0.24, 12, 12),
                new THREE.MeshStandardMaterial({
                    color: Math.abs(i) % 2.2 < 1 ? 0xff7700 : 0xffc300,
                    roughness: 0.85
                })
            );
            marigold.position.set(i, 7.0 + Math.sin(i * 0.8) * 0.3, -0.45);
            pandal.add(marigold);
        }

        // 4. Altar Chowki Table
        const chowki = new THREE.Mesh(
            new THREE.BoxGeometry(4.4, 0.6, 3.4),
            new THREE.MeshStandardMaterial({ color: 0x4a180d, roughness: 0.7 })
        );
        chowki.position.set(0, 1.05, -4.5);
        chowki.castShadow = true;
        chowki.receiveShadow = true;
        pandal.add(chowki);

        const cloth = new THREE.Mesh(
            new THREE.BoxGeometry(4.6, 0.1, 3.6),
            new THREE.MeshStandardMaterial({ color: 0xba181b, roughness: 0.5 })
        );
        cloth.position.set(0, 1.38, -4.5);
        pandal.add(cloth);

        // 5. Perimeter Diyas around the platform
        for (let i = 0; i < 18; i++) {
            const angle = (i / 18) * Math.PI * 2;
            const dx = Math.cos(angle) * 8.2;
            const dz = -4.5 + Math.sin(angle) * 8.2;

            const diya = new THREE.Group();
            const bowl = new THREE.Mesh(
                new THREE.CylinderGeometry(0.24, 0.12, 0.14, 14),
                new THREE.MeshStandardMaterial({ color: 0xa84214, roughness: 0.85 })
            );
            diya.add(bowl);

            const flame = new THREE.Mesh(
                new THREE.ConeGeometry(0.09, 0.26, 12),
                new THREE.MeshStandardMaterial({
                    color: 0xffffff,
                    emissive: 0xff6600,
                    emissiveIntensity: 4.5
                })
            );
            flame.position.y = 0.18;
            diya.add(flame);

            diya.position.set(dx, 0.85, dz);
            pandal.add(diya);
            this.diyas.push({ group: diya, flame: flame });
        }

        this.scene.add(pandal);
        this.pandalGroup = pandal;
    }

    /**
     * Distinct neighborhood houses with unique features:
     * Tulsi planter, tiled roof, rangoli, flower gardens, porches, and balconies.
     */
    buildNeighborhoodHouses() {
        const houseDefinitions = [
            {
                id: "house_ravi",
                family: "Ravi & Family",
                resident: "Ravi",
                role: "Pandal Committee Volunteer",
                dialogue: "Namaste! Our family has been waiting for you. Here is ₹300 Chanda for Bappa's celebration!",
                donationType: "chanda",
                amount: 300,
                x: -12,
                z: 6,
                rotY: Math.PI / 2,
                color: 0xd9822b, // Terracotta walls
                roofColor: 0x8a2817,
                feature: "garland"
            },
            {
                id: "house_lakshmi",
                family: "Lakshmi's Family",
                resident: "Lakshmi",
                role: "Devout Homemaker",
                dialogue: "Namaste! I prepared special homemade coconut sweets, and here are ₹250 plus fresh red hibiscus flowers!",
                donationType: "chanda_and_flowers",
                amount: 250,
                flowers: 12,
                x: -12,
                z: 14,
                rotY: Math.PI / 2,
                color: 0xdfa067, // Cream Ochre
                roofColor: 0x661810,
                feature: "tulsi"
            },
            {
                id: "house_anitha",
                family: "Anitha's Family",
                resident: "Anitha",
                role: "Rangoli Artisan",
                dialogue: "Namaste! I have prepared natural colors for the entrance rangoli, and here are ₹200 for the lighting!",
                donationType: "chanda",
                amount: 200,
                x: -12,
                z: 22,
                rotY: Math.PI / 2,
                color: 0xc47b58,
                roofColor: 0x7c2d12,
                feature: "rangoli"
            },
            {
                id: "house_dadu",
                family: "Grandfather Dadu",
                resident: "Dadu",
                role: "Village Elder",
                dialogue: "Bless you, Mushika! In our youth, we celebrated with great pomp. Accept ₹500 and these auspicious coconuts.",
                donationType: "chanda_and_coconut",
                amount: 500,
                coconuts: 3,
                x: 12,
                z: 6,
                rotY: -Math.PI / 2,
                color: 0xbc6c25,
                roofColor: 0x5a1808,
                feature: "lantern"
            },
            {
                id: "house_aarav",
                family: "Aarav's Family",
                resident: "Little Aarav",
                role: "Enthusiastic Child",
                dialogue: "Bappa is coming! I saved ₹100 from my pocket money and collected tender bananas for prasad!",
                donationType: "chanda_and_fruits",
                amount: 100,
                fruits: 8,
                x: 12,
                z: 14,
                rotY: -Math.PI / 2,
                color: 0xe09f3e,
                roofColor: 0x9e2a2b,
                feature: "bunting"
            },
            {
                id: "house_suresh",
                family: "Suresh's Family & Store",
                resident: "Suresh",
                role: "Local Merchant",
                dialogue: "Business flourishes when Bappa arrives! Here are ₹350 and pure ghee diyas for the altar.",
                donationType: "chanda_and_diyas",
                amount: 350,
                diyas: 6,
                x: 12,
                z: 22,
                rotY: -Math.PI / 2,
                color: 0xcd7b32,
                roofColor: 0x540b0e,
                feature: "shop_veranda"
            },
            {
                id: "house_meera",
                family: "Meera's Family",
                resident: "Meera",
                role: "Music Teacher",
                dialogue: "Namaste! Our society has collected ₹250. We will sing Aarti bhajans together this evening!",
                donationType: "chanda",
                amount: 250,
                x: -5,
                z: 24,
                rotY: 0,
                color: 0xd4a373,
                roofColor: 0x7f2918,
                feature: "apartment"
            },
            {
                id: "house_sharma",
                family: "The Sharma Family",
                resident: "Pandit Sharma",
                role: "Traditional Scholar",
                dialogue: "Ganpati Bappa Morya! Here are ₹300 and sacred 21-blade Durva grass gathered this morning.",
                donationType: "chanda_and_durva",
                amount: 300,
                x: 5,
                z: 24,
                rotY: 0,
                color: 0xb5651d,
                roofColor: 0x6e1b0c,
                feature: "toran"
            }
        ];

        houseDefinitions.forEach((def) => {
            const house = this.createHouseMesh(def);
            house.position.set(def.x, 0, def.z);
            house.rotation.y = def.rotY;

            house.userData = {
                def: def,
                isInteractable: true,
                visited: false,
                doorPosition: new THREE.Vector3(def.x, 0.8, def.z)
            };

            this.scene.add(house);
            this.houses.push(house);
        });
    }

    createHouseMesh(def) {
        const group = new THREE.Group();

        // 1. House Main Body
        const width = 5.5, height = 3.8, depth = 5.0;
        const wallMat = new THREE.MeshStandardMaterial({ color: def.color, roughness: 0.85 });
        const body = new THREE.Mesh(new THREE.BoxGeometry(width, height, depth), wallMat);
        body.position.y = height / 2;
        body.castShadow = true;
        body.receiveShadow = true;
        group.add(body);

        // 2. Sloped Tiled Roof
        const roofMat = new THREE.MeshStandardMaterial({ color: def.roofColor, roughness: 0.75 });
        const roof = new THREE.Mesh(new THREE.ConeGeometry(4.4, 2.0, 4), roofMat);
        roof.position.y = height + 0.95;
        roof.rotation.y = Math.PI / 4;
        roof.scale.set(1.0, 1.0, 0.85);
        roof.castShadow = true;
        group.add(roof);

        // 3. Wooden Entrance Door
        const doorMat = new THREE.MeshStandardMaterial({ color: 0x3d1c06, roughness: 0.7 });
        const door = new THREE.Mesh(new THREE.BoxGeometry(1.4, 2.3, 0.15), doorMat);
        door.position.set(0, 1.15, depth / 2 + 0.08);
        door.castShadow = true;
        group.add(door);

        // Door golden brass handle
        const handle = new THREE.Mesh(
            new THREE.SphereGeometry(0.08, 10, 10),
            new THREE.MeshStandardMaterial({ color: 0xffd166, metalness: 0.8 })
        );
        handle.position.set(0.45, 1.15, depth / 2 + 0.18);
        group.add(handle);

        // 4. Windows with wooden grilles
        [-1.8, 1.8].forEach((wx) => {
            const win = new THREE.Mesh(
                new THREE.BoxGeometry(0.9, 1.0, 0.1),
                new THREE.MeshStandardMaterial({ color: 0xfff3b0, emissive: 0xffb703, emissiveIntensity: 0.4 })
            );
            win.position.set(wx, 2.2, depth / 2 + 0.06);
            group.add(win);
        });

        // 5. Unique Cultural Features
        if (def.feature === "tulsi") {
            // Tulsi Vrindavan stone planter
            const pot = new THREE.Mesh(
                new THREE.BoxGeometry(0.7, 0.8, 0.7),
                new THREE.MeshStandardMaterial({ color: 0xc87d55 })
            );
            pot.position.set(1.6, 0.4, depth / 2 + 0.9);
            group.add(pot);

            const plant = new THREE.Mesh(
                new THREE.SphereGeometry(0.35, 12, 12),
                new THREE.MeshStandardMaterial({ color: 0x2d6a4f, roughness: 0.8 })
            );
            plant.position.set(1.6, 1.05, depth / 2 + 0.9);
            group.add(plant);
        } else if (def.feature === "rangoli") {
            // Mini rangoli patch at entrance
            const miniR = new THREE.Mesh(
                new THREE.CircleGeometry(0.9, 24).rotateX(-Math.PI / 2),
                new THREE.MeshBasicMaterial({ color: 0xffd166, side: THREE.DoubleSide })
            );
            miniR.position.set(0, 0.03, depth / 2 + 0.8);
            group.add(miniR);
        } else if (def.feature === "lantern") {
            // Hanging brass Kandil lantern
            const kandil = new THREE.Mesh(
                new THREE.OctahedronGeometry(0.35),
                new THREE.MeshStandardMaterial({ color: 0xffd166, emissive: 0xff8800, emissiveIntensity: 2.0 })
            );
            kandil.position.set(0, 3.2, depth / 2 + 0.5);
            group.add(kandil);
        }

        // Floating glowing door interaction marker
        const marker = new THREE.Mesh(
            new THREE.SphereGeometry(0.2, 14, 14),
            new THREE.MeshStandardMaterial({
                color: 0xffd166,
                emissive: 0xffa000,
                emissiveIntensity: 0.9
            })
        );
        marker.position.set(0, 2.9, depth / 2 + 0.4);
        group.add(marker);
        group.userData.marker = marker;

        return group;
    }

    /**
     * Ganesha Murti Workshop / Karkhana
     * A beautifully illuminated artisan workshop where 3 distinct Ganesha idols reside
     */
    buildMurtiWorkshop() {
        const group = new THREE.Group();
        const wx = 18, wz = -6;

        // Workshop raised floor
        const floor = new THREE.Mesh(
            new THREE.BoxGeometry(11, 0.4, 9),
            new THREE.MeshStandardMaterial({ color: 0x6e3c1b, roughness: 0.8 })
        );
        floor.position.set(0, 0.2, 0);
        floor.receiveShadow = true;
        group.add(floor);

        // Open awning canopy
        const canopy = new THREE.Mesh(
            new THREE.BoxGeometry(11.4, 0.2, 9.4),
            new THREE.MeshStandardMaterial({ color: 0xba181b, roughness: 0.6 })
        );
        canopy.position.set(0, 4.5, 0);
        group.add(canopy);

        // Signboard
        const signCanvas = document.createElement("canvas");
        signCanvas.width = 512; signCanvas.height = 128;
        const sCtx = signCanvas.getContext("2d");
        sCtx.fillStyle = "#ffe28a";
        sCtx.fillRect(0, 0, 512, 128);
        sCtx.fillStyle = "#800000";
        sCtx.font = "bold 44px serif";
        sCtx.textAlign = "center";
        sCtx.textBaseline = "middle";
        sCtx.fillText("🐘 SHREE GANESH KALAKENDRA", 256, 64);
        const signTex = new THREE.CanvasTexture(signCanvas);
        const signMesh = new THREE.Mesh(
            new THREE.PlaneGeometry(6.5, 1.4),
            new THREE.MeshBasicMaterial({ map: signTex })
        );
        signMesh.position.set(0, 4.2, 4.75);
        group.add(signMesh);

        // 3 Murti Pedestals inside workshop
        this.murtiPedestals = [
            {
                id: "murti_lalbaug",
                name: "Raja Swaroop Ganesha",
                desc: "Majestic seated idol with royal Mukut crown and blessings.",
                style: "Royal & Grand",
                x: -3.2,
                z: -1.2
            },
            {
                id: "murti_eco",
                name: "Shadu Mati Eco-Ganesha",
                desc: "Crafted from pure natural clay with organic turmeric & sindoor paints.",
                style: "Sacred & Pure",
                x: 0,
                z: -1.2
            },
            {
                id: "murti_bal",
                name: "Bal Ganesha (Joyful Form)",
                desc: "Charming youthful idol holding sweet modaks with benevolent smile.",
                style: "Sweet & Benevolent",
                x: 3.2,
                z: -1.2
            }
        ];

        this.murtiPedestals.forEach((m) => {
            const pGroup = new THREE.Group();
            const ped = new THREE.Mesh(
                new THREE.CylinderGeometry(1.0, 1.1, 0.9, 20),
                new THREE.MeshStandardMaterial({ color: 0xd69e3d, metalness: 0.6, roughness: 0.3 })
            );
            ped.position.y = 0.65;
            ped.castShadow = true;
            pGroup.add(ped);

            // Miniature representative statue
            const miniStatue = new THREE.Mesh(
                new THREE.CylinderGeometry(0.4, 0.6, 1.4, 16),
                new THREE.MeshStandardMaterial({ color: 0xffaa00, roughness: 0.4 })
            );
            miniStatue.position.y = 1.8;
            pGroup.add(miniStatue);

            pGroup.position.set(m.x, 0, m.z);
            pGroup.userData = {
                murti: m,
                isMurtiOption: true,
                isInteractable: true
            };
            group.add(pGroup);
        });

        group.position.set(wx, 0, wz);
        this.scene.add(group);
        this.workshopGroup = group;
    }

    loadGaneshaModel() {
        const loader = new GLTFLoader();

        // Celestial Aura behind Ganesha
        const haloGeo = new THREE.CircleGeometry(3.6, 48);
        const haloCanvas = document.createElement("canvas");
        haloCanvas.width = 256; haloCanvas.height = 256;
        const hctx = haloCanvas.getContext("2d");
        const grad = hctx.createRadialGradient(128, 128, 20, 128, 128, 128);
        grad.addColorStop(0, "rgba(255, 230, 130, 0.95)");
        grad.addColorStop(0.5, "rgba(255, 170, 40, 0.65)");
        grad.addColorStop(1, "rgba(255, 100, 0, 0)");
        hctx.fillStyle = grad;
        hctx.fillRect(0, 0, 256, 256);

        const haloTex = new THREE.CanvasTexture(haloCanvas);
        this.halo = new THREE.Mesh(
            haloGeo,
            new THREE.MeshBasicMaterial({
                map: haloTex,
                transparent: true,
                opacity: 0.7,
                side: THREE.DoubleSide,
                depthWrite: false
            })
        );
        this.halo.position.set(0, 4.0, -5.2);
        this.scene.add(this.halo);

        // Royal crimson veil covering Ganesha prior to arrival
        const veilGeo = new THREE.ConeGeometry(2.5, 4.4, 24);
        this.veil = new THREE.Mesh(
            veilGeo,
            new THREE.MeshStandardMaterial({ color: 0xc1121f, roughness: 0.5 })
        );
        this.veil.position.set(0, 3.4, -4.5);
        this.scene.add(this.veil);

        // Load 22MB ganesha.glb model
        loader.load(
            "/models/ganesha.glb",
            (gltf) => {
                this.ganeshaModel = gltf.scene;
                this.ganeshaModel.scale.set(2.1, 2.1, 2.1);
                this.ganeshaModel.position.set(0, 1.4, -4.5);
                this.ganeshaModel.rotation.y = Math.PI;

                this.ganeshaModel.traverse((o) => {
                    if (o.isMesh) {
                        o.castShadow = true;
                        o.receiveShadow = true;
                    }
                });

                this.scene.add(this.ganeshaModel);
                console.log("Lord Ganesha 3D idol loaded cleanly!");
            },
            undefined,
            (err) => console.error("Error loading ganesha.glb:", err)
        );
    }

    revealGanesha(onComplete) {
        if (this.isGaneshaRevealed) {
            if (onComplete) onComplete();
            return;
        }

        if (this.veil) {
            let p = 0;
            const timer = setInterval(() => {
                p += 0.05;
                this.veil.position.y -= 0.1;
                this.veil.scale.multiplyScalar(0.95);
                if (this.veil.material) {
                    this.veil.material.transparent = true;
                    this.veil.material.opacity = Math.max(0, 1 - p);
                }
                if (p >= 1) {
                    clearInterval(timer);
                    this.scene.remove(this.veil);
                    this.isGaneshaRevealed = true;
                    if (onComplete) onComplete();
                }
            }, 30);
        } else {
            this.isGaneshaRevealed = true;
            if (onComplete) onComplete();
        }
    }

    update(time, delta) {
        // Floating breathe motion for Ganesha
        if (this.ganeshaModel && this.isGaneshaRevealed) {
            this.ganeshaModel.position.y = 1.4 + Math.sin(time * 1.8) * 0.04;
        }

        // Halo rotation and pulsing
        if (this.halo) {
            this.halo.scale.setScalar(1.0 + Math.sin(time * 2.5) * 0.06);
            this.halo.rotation.z = time * 0.1;
        }

        // Diya flames flickering
        this.diyas.forEach((d, idx) => {
            const flick = 0.9 + Math.sin(time * 8 + idx * 2) * 0.15;
            d.flame.scale.set(flick, flick * 1.1, flick);
        });

        // House door markers bobbing
        this.houses.forEach((h) => {
            if (!h.userData.visited && h.userData.marker) {
                h.userData.marker.position.y = 2.9 + Math.sin(time * 4 + h.position.x) * 0.12;
            }
        });
    }
}
