/**
 * Audio System for Ganesha — The Festival Guardian
 * Uses Web Audio API for high-quality procedural festival sound design.
 * Provides authentic Indian temple bells, conch shell, dholak beats, aarti melodies,
 * coin chimes, shopping sounds, and fireworks without external audio file dependencies.
 */

class FestivalAudioSystem {
    constructor() {
        this.ctx = null;
        this.masterGain = null;
        this.ambientGain = null;
        this.initialized = false;
        this.isMuted = false;
        this.tanpuraOscs = [];
    }

    init() {
        if (this.initialized) return;
        try {
            const AudioContext = window.AudioContext || window.webkitAudioContext;
            this.ctx = new AudioContext();
            this.masterGain = this.ctx.createGain();
            this.masterGain.gain.setValueAtTime(0.7, this.ctx.currentTime);
            this.masterGain.connect(this.ctx.destination);

            this.ambientGain = this.ctx.createGain();
            this.ambientGain.gain.setValueAtTime(0.25, this.ctx.currentTime);
            this.ambientGain.connect(this.masterGain);

            this.initialized = true;
        } catch (e) {
            console.warn("Web Audio API not supported or blocked", e);
        }
    }

    resume() {
        if (this.ctx && this.ctx.state === "suspended") {
            this.ctx.resume();
        }
    }

    /**
     * Resonant Indian Temple Bell (Brass Ghanta)
     * Rich multi-harmonic ringing with natural damping
     */
    playTempleBell(pitch = 1.0) {
        if (!this.initialized) this.init();
        this.resume();
        if (!this.ctx) return;

        const now = this.ctx.currentTime;
        const freqs = [587.33, 880, 1174.66, 1760, 2637].map(f => f * pitch);
        const gains = [0.4, 0.3, 0.2, 0.12, 0.05];

        freqs.forEach((freq, idx) => {
            const osc = this.ctx.createOscillator();
            const gain = this.ctx.createGain();

            osc.type = idx === 0 ? "sine" : "triangle";
            osc.frequency.setValueAtTime(freq, now);
            osc.frequency.exponentialRampToValueAtTime(freq * 0.998, now + 3.0);

            const initialGain = gains[idx] || 0.1;
            gain.gain.setValueAtTime(initialGain, now);
            const decay = 2.5 + idx * 0.4;
            gain.gain.exponentialRampToValueAtTime(0.0001, now + decay);

            osc.connect(gain);
            gain.connect(this.masterGain);

            osc.start(now);
            osc.stop(now + decay);
        });
    }

    /**
     * Sacred Conch Shell (Shankha) Call
     * Brassy, majestic resonant drone with vibrato
     */
    playConchCall() {
        if (!this.initialized) this.init();
        this.resume();
        if (!this.ctx) return;

        const now = this.ctx.currentTime;
        const baseFreq = 220; // A3

        const osc = this.ctx.createOscillator();
        const subOsc = this.ctx.createOscillator();
        const gain = this.ctx.createGain();
        const filter = this.ctx.createBiquadFilter();

        osc.type = "sawtooth";
        subOsc.type = "sine";

        osc.frequency.setValueAtTime(baseFreq, now);
        osc.frequency.linearRampToValueAtTime(baseFreq * 1.35, now + 1.2);
        osc.frequency.exponentialRampToValueAtTime(baseFreq * 1.33, now + 3.5);

        subOsc.frequency.setValueAtTime(baseFreq / 2, now);
        subOsc.frequency.linearRampToValueAtTime((baseFreq * 1.35) / 2, now + 1.2);

        filter.type = "lowpass";
        filter.frequency.setValueAtTime(400, now);
        filter.frequency.linearRampToValueAtTime(1400, now + 1.2);
        filter.frequency.exponentialRampToValueAtTime(600, now + 3.8);

        gain.gain.setValueAtTime(0.001, now);
        gain.gain.linearRampToValueAtTime(0.35, now + 1.0);
        gain.gain.setValueAtTime(0.35, now + 2.8);
        gain.gain.exponentialRampToValueAtTime(0.0001, now + 4.0);

        osc.connect(filter);
        subOsc.connect(filter);
        filter.connect(gain);
        gain.connect(this.masterGain);

        osc.start(now);
        subOsc.start(now);
        osc.stop(now + 4.0);
        subOsc.stop(now + 4.0);
    }

    /**
     * Coin collection chime (+₹ Chanda)
     */
    playCoinSound() {
        if (!this.initialized) this.init();
        this.resume();
        if (!this.ctx) return;

        const now = this.ctx.currentTime;
        const notes = [987.77, 1318.51, 1567.98]; // B5, E6, G6
        notes.forEach((note, i) => {
            const osc = this.ctx.createOscillator();
            const gain = this.ctx.createGain();
            const timeOffset = now + i * 0.07;

            osc.type = "sine";
            osc.frequency.setValueAtTime(note, timeOffset);

            gain.gain.setValueAtTime(0.2, timeOffset);
            gain.gain.exponentialRampToValueAtTime(0.001, timeOffset + 0.3);

            osc.connect(gain);
            gain.connect(this.masterGain);

            osc.start(timeOffset);
            osc.stop(timeOffset + 0.35);
        });
    }

    /**
     * Shop item purchased chime
     */
    playPurchaseSound() {
        if (!this.initialized) this.init();
        this.resume();
        if (!this.ctx) return;

        const now = this.ctx.currentTime;
        const freqs = [523.25, 659.25, 783.99, 1046.50]; // C Major arpeggio
        freqs.forEach((freq, idx) => {
            const osc = this.ctx.createOscillator();
            const gain = this.ctx.createGain();
            const t = now + idx * 0.06;

            osc.type = "triangle";
            osc.frequency.setValueAtTime(freq, t);

            gain.gain.setValueAtTime(0.18, t);
            gain.gain.exponentialRampToValueAtTime(0.001, t + 0.25);

            osc.connect(gain);
            gain.connect(this.masterGain);

            osc.start(t);
            osc.stop(t + 0.3);
        });
    }

    /**
     * Correct placement snap sound (Pandal / Puja items)
     */
    playSnapSound() {
        if (!this.initialized) this.init();
        this.resume();
        if (!this.ctx) return;

        const now = this.ctx.currentTime;
        const osc = this.ctx.createOscillator();
        const gain = this.ctx.createGain();

        osc.type = "sine";
        osc.frequency.setValueAtTime(659.25, now);
        osc.frequency.exponentialRampToValueAtTime(1318.51, now + 0.15);

        gain.gain.setValueAtTime(0.25, now);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 0.35);

        osc.connect(gain);
        gain.connect(this.masterGain);

        osc.start(now);
        osc.stop(now + 0.4);
    }

    /**
     * Dholak / Drum festival beat
     */
    playDholakBeat(type = "bass") {
        if (!this.initialized) this.init();
        this.resume();
        if (!this.ctx) return;

        const now = this.ctx.currentTime;
        const osc = this.ctx.createOscillator();
        const gain = this.ctx.createGain();

        if (type === "bass") {
            osc.type = "sine";
            osc.frequency.setValueAtTime(140, now);
            osc.frequency.exponentialRampToValueAtTime(45, now + 0.18);

            gain.gain.setValueAtTime(0.45, now);
            gain.gain.exponentialRampToValueAtTime(0.001, now + 0.22);
        } else {
            osc.type = "triangle";
            osc.frequency.setValueAtTime(440, now);
            osc.frequency.exponentialRampToValueAtTime(220, now + 0.08);

            gain.gain.setValueAtTime(0.25, now);
            gain.gain.exponentialRampToValueAtTime(0.001, now + 0.12);
        }

        osc.connect(gain);
        gain.connect(this.masterGain);

        osc.start(now);
        osc.stop(now + 0.25);
    }

    /**
     * Aarti Rhythm Note (synthesized traditional note with sweet timbre)
     */
    playAartiNote(freq = 440, duration = 0.4) {
        if (!this.initialized) this.init();
        this.resume();
        if (!this.ctx) return;

        const now = this.ctx.currentTime;
        const osc = this.ctx.createOscillator();
        const gain = this.ctx.createGain();
        const filter = this.ctx.createBiquadFilter();

        osc.type = "sawtooth";
        osc.frequency.setValueAtTime(freq, now);

        filter.type = "lowpass";
        filter.frequency.setValueAtTime(1200, now);

        gain.gain.setValueAtTime(0.001, now);
        gain.gain.linearRampToValueAtTime(0.2, now + 0.04);
        gain.gain.exponentialRampToValueAtTime(0.001, now + duration);

        osc.connect(filter);
        filter.connect(gain);
        gain.connect(this.masterGain);

        osc.start(now);
        osc.stop(now + duration);
    }

    /**
     * Start soft ambient festival drone (Tanpura C# / G#)
     */
    startAmbient() {
        if (!this.initialized) this.init();
        this.resume();
        if (!this.ctx || this.tanpuraOscs.length > 0) return;

        const now = this.ctx.currentTime;
        const notes = [138.59, 207.65, 277.18]; // C#3, G#3, C#4

        notes.forEach((freq, idx) => {
            const osc = this.ctx.createOscillator();
            const gain = this.ctx.createGain();

            osc.type = "sine";
            osc.frequency.setValueAtTime(freq, now);

            const lfo = this.ctx.createOscillator();
            const lfoGain = this.ctx.createGain();
            lfo.frequency.setValueAtTime(0.2 + idx * 0.1, now);
            lfoGain.gain.setValueAtTime(0.03, now);
            lfo.connect(lfoGain);
            lfoGain.connect(gain.gain);

            gain.gain.setValueAtTime(0.08, now);

            osc.connect(gain);
            gain.connect(this.ambientGain);

            osc.start(now);
            lfo.start(now);

            this.tanpuraOscs.push({ osc, lfo, gain });
        });
    }

    stopAmbient() {
        this.tanpuraOscs.forEach(o => {
            try {
                o.osc.stop();
                o.lfo.stop();
            } catch (e) {}
        });
        this.tanpuraOscs = [];
    }

    /**
     * Festive Firework burst with sparkle crackle
     */
    playFireworkSound() {
        if (!this.initialized) this.init();
        this.resume();
        if (!this.ctx) return;

        const now = this.ctx.currentTime;

        const bufferSize = Math.floor(this.ctx.sampleRate * 0.7);
        const buffer = this.ctx.createBuffer(1, bufferSize, this.ctx.sampleRate);
        const data = buffer.getChannelData(0);
        for (let i = 0; i < bufferSize; i++) {
            data[i] = Math.random() * 2 - 1;
        }

        const noise = this.ctx.createBufferSource();
        noise.buffer = buffer;

        const filter = this.ctx.createBiquadFilter();
        filter.type = "lowpass";
        filter.frequency.setValueAtTime(800, now);
        filter.frequency.exponentialRampToValueAtTime(120, now + 0.5);

        const gain = this.ctx.createGain();
        gain.gain.setValueAtTime(0.4, now);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 0.7);

        noise.connect(filter);
        filter.connect(gain);
        gain.connect(this.masterGain);

        noise.start(now);

        for (let i = 0; i < 3; i++) {
            const crackleTime = now + 0.15 + Math.random() * 0.35;
            const osc = this.ctx.createOscillator();
            const cGain = this.ctx.createGain();
            osc.type = "triangle";
            osc.frequency.setValueAtTime(1200 + Math.random() * 1200, crackleTime);

            cGain.gain.setValueAtTime(0.08, crackleTime);
            cGain.gain.exponentialRampToValueAtTime(0.001, crackleTime + 0.1);

            osc.connect(cGain);
            cGain.connect(this.masterGain);

            osc.start(crackleTime);
            osc.stop(crackleTime + 0.12);
        }
    }

    playClick() {
        if (!this.initialized) this.init();
        this.resume();
        if (!this.ctx) return;

        const now = this.ctx.currentTime;
        const osc = this.ctx.createOscillator();
        const gain = this.ctx.createGain();

        osc.type = "sine";
        osc.frequency.setValueAtTime(800, now);
        osc.frequency.exponentialRampToValueAtTime(300, now + 0.05);

        gain.gain.setValueAtTime(0.15, now);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 0.05);

        osc.connect(gain);
        gain.connect(this.masterGain);

        osc.start(now);
        osc.stop(now + 0.06);
    }
}

export const audioSystem = new FestivalAudioSystem();
