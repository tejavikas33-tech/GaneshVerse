/**
 * Interaction System for Ganesha — The Festival Guardian
 * Supports both Keyboard ('E' / 'Space') and Mouse Click on interactables.
 */
import * as THREE from "three";

export class InteractionManager {
    constructor(camera, domElement, onInteractCallback) {
        this.camera = camera;
        this.domElement = domElement;
        this.onInteractCallback = onInteractCallback;
        this.raycaster = new THREE.Raycaster();
        this.mouse = new THREE.Vector2();
        this.interactables = [];
        this.currentHovered = null;

        this.initListeners();
    }

    setInteractables(list) {
        this.interactables = list;
    }

    initListeners() {
        // 1. Keyboard 'E' / 'Space'
        window.addEventListener("keydown", (e) => {
            if (e.key.toLowerCase() === "e" || e.code === "Space") {
                if (this.onInteractCallback) {
                    this.onInteractCallback();
                }
            }
        });

        // 2. Mouse Click Raycast
        this.domElement.addEventListener("pointerdown", (e) => {
            // Ignore clicks if clicking on a UI button/modal
            if (e.target.closest && e.target.closest(".festival-card, #play-button, button")) return;

            const rect = this.domElement.getBoundingClientRect();
            this.mouse.x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
            this.mouse.y = -((e.clientY - rect.top) / rect.height) * 2 + 1;

            this.raycaster.setFromCamera(this.mouse, this.camera);
            const intersects = this.raycaster.intersectObjects(this.interactables, true);

            if (intersects.length > 0) {
                // Find top-level registered interactable
                let hitObj = intersects[0].object;
                while (hitObj && !hitObj.userData.isInteractable && hitObj.parent) {
                    hitObj = hitObj.parent;
                }
                if (hitObj && hitObj.userData.isInteractable) {
                    if (this.onInteractCallback) {
                        this.onInteractCallback(hitObj);
                    }
                }
            }
        });
    }
}
