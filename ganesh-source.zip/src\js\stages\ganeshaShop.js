/**
 * Stage 2: Ganesha Shop / Murti Search
 * Player visits the artisan workshop (Shree Ganesh Kalakendra),
 * inspects several authentic Ganesha idols with different forms and blessings,
 * and selects the presiding idol for the pandal.
 */
import * as THREE from "three";
import { gameState } from "../gameState.js";
import { audioSystem } from "../systems/audio.js";

export class GaneshaShopStage {
    constructor(game) {
        this.game = game;
        this.world = game.world;
        this.ui = game.ui;
        this.particles = game.particles;
        this.nearbyPedestal = null;
    }

    start() {
        this.updateHUD();
        // Guide player toward workshop on east side
        this.ui.showFloatingBadge("Walk to the Murti Workshop on the East road! ▶", "#ffe28a");
        audioSystem.playTempleBell(1.0);
    }

    updateHUD() {
        this.ui.updateHUD({
            stageNum: 2,
            stageName: "GANESHA SHOP — MURTI SEARCH",
            objective: "Explore Shree Ganesh Kalakendra workshop and select the festival idol.",
            score: gameState.score,
            chanda: gameState.chanda,
            progress: "Choose Murti"
        });
    }

    update(time, delta) {
        const playerPos = this.game.player.position;
        let closest = null;
        let closestDist = 3.2;

        if (this.world.murtiPedestals) {
            this.world.murtiPedestals.forEach((m) => {
                // World coordinates of pedestal
                const worldPos = new THREE.Vector3(18 + m.x, 1.0, -6 + m.z);
                const dist = playerPos.distanceTo(worldPos);
                if (dist < closestDist) {
                    closestDist = dist;
                    closest = m;
                }
            });
        }

        if (closest !== this.nearbyPedestal) {
            this.nearbyPedestal = closest;
            if (this.nearbyPedestal) {
                this.ui.showPrompt(`Inspect ${this.nearbyPedestal.name} (E / Click)`);
            } else {
                this.ui.hidePrompt();
            }
        }
    }

    handleInteraction(clickedObj) {
        let m = this.nearbyPedestal;
        if (clickedObj && clickedObj.userData && clickedObj.userData.murti) {
            m = clickedObj.userData.murti;
        }

        if (!m) return;
        this.openMurtiInspectModal(m);
    }

    openMurtiInspectModal(murti) {
        audioSystem.playClick();

        this.ui.modalContainer.innerHTML = `
            <div class="festival-card dialogue-card">
                <div class="card-header">
                    <span class="icon">🐘</span>
                    <div>
                        <h2>${murti.name}</h2>
                        <span class="role">Style: ${murti.style}</span>
                    </div>
                </div>

                <p class="devotee-quote">"${murti.desc}"</p>

                <div class="donation-highlight">
                    <span>Artisan Consecration Status</span>
                    <strong class="donation-amt">Ready for Sacred Pandal</strong>
                </div>

                <div class="btn-group">
                    <button id="btn-select-murti" class="btn-primary">
                        🙏 SELECT AS FESTIVAL IDOL
                    </button>
                    <button id="btn-inspect-other" class="btn-secondary">
                        INSPECT OTHERS
                    </button>
                </div>
            </div>
        `;

        this.ui.modalContainer.classList.remove("hidden");

        document.getElementById("btn-select-murti").onclick = () => {
            this.selectMurti(murti);
        };

        document.getElementById("btn-inspect-other").onclick = () => {
            audioSystem.playClick();
            this.ui.clearModal();
        };
    }

    selectMurti(murti) {
        gameState.setMurti(murti);
        this.ui.clearModal();

        audioSystem.playTempleBell(1.2);
        audioSystem.playDholakBeat("bass");

        this.particles.burstSparkles(this.game.player.position.x, 2.0, this.game.player.position.z, 35);
        this.ui.showFloatingBadge(`Selected: ${murti.name}!`, "#ffd166");

        setTimeout(() => {
            this.finishStage();
        }, 1200);
    }

    finishStage() {
        this.ui.showStageComplete({
            stageNum: 2,
            stageTitle: "MURTI SELECTION COMPLETE",
            description: `You reverently selected "${gameState.selectedMurti.name}" (${gameState.selectedMurti.style}) from the artisans. The neighborhood gathers to transport Lord Ganesha safely to our festival pandal!`,
            stats: [
                { label: "Selected Murti", value: gameState.selectedMurti.name },
                { label: "Artisan Blessing", value: "Auspicious & Sacred" },
                { label: "Festival Seva Score", value: `+${gameState.score}` }
            ],
            nextStageTitle: "Stage 3: Ganesha Arrival & Unveiling",
            onNext: () => {
                this.cleanup();
                this.game.startStage(3);
            }
        });
    }

    cleanup() {
        this.ui.hidePrompt();
    }
}
