/**
 * Mushika (Mouse) Player Character Controller
 * Faithful divine vehicle (vahana) of Lord Ganesha.
 */
import * as THREE from "three";

export class MushikaPlayer {
    constructor(scene) {
        this.scene = scene;
        this.mesh = new THREE.Group();
        this.speed = 0.12;
        this.velocity = new THREE.Vector3();
        this.isMoving = false;
        this.facingAngle = 0;
        this.bounds = { minX: -24, maxX: 24, minZ: -10, maxZ: 30 };

        this.buildCharacter();
        this.scene.add(this.mesh);

        this.resetPosition();
    }

    buildCharacter() {
        // Material definitions
        const furMaterial = new THREE.MeshStandardMaterial({
            color: 0x824927,
            roughness: 0.7,
            metalness: 0.1
        });

        const bellyMaterial = new THREE.MeshStandardMaterial({
            color: 0xd49b6a,
            roughness: 0.8
        });

        const innerEarMaterial = new THREE.MeshStandardMaterial({
            color: 0xe07a7a,
            roughness: 0.6
        });

        const eyeMaterial = new THREE.MeshStandardMaterial({
            color: 0x111111,
            roughness: 0.2,
            metalness: 0.8
        });

        const goldMaterial = new THREE.MeshStandardMaterial({
            color: 0xffb703,
            metalness: 0.85,
            roughness: 0.2,
            emissive: 0x4a2800
        });

        // 1. Torso (chubby, cute mouse body)
        const bodyGeo = new THREE.SphereGeometry(0.55, 24, 24);
        bodyGeo.scale(1.2, 0.9, 0.95);
        this.body = new THREE.Mesh(bodyGeo, furMaterial);
        this.body.position.set(0, 0.45, 0);
        this.body.castShadow = true;
        this.mesh.add(this.body);

        // Belly patch
        const bellyGeo = new THREE.SphereGeometry(0.48, 16, 16);
        bellyGeo.scale(1.0, 0.75, 0.85);
        const belly = new THREE.Mesh(bellyGeo, bellyMaterial);
        belly.position.set(0.08, 0.38, 0);
        this.mesh.add(belly);

        // 2. Head (tapered snout)
        const headGeo = new THREE.ConeGeometry(0.38, 0.65, 20);
        headGeo.rotateZ(-Math.PI / 2); // points forward along +X
        this.head = new THREE.Mesh(headGeo, furMaterial);
        this.head.position.set(0.62, 0.52, 0);
        this.head.castShadow = true;
        this.mesh.add(this.head);

        // Pink nose tip
        const noseGeo = new THREE.SphereGeometry(0.08, 12, 12);
        const noseMat = new THREE.MeshStandardMaterial({ color: 0xdb5a6b, roughness: 0.5 });
        const nose = new THREE.Mesh(noseGeo, noseMat);
        nose.position.set(0.96, 0.52, 0);
        this.mesh.add(nose);

        // 3. Ears (large, rounded, festive)
        const earGeo = new THREE.CylinderGeometry(0.24, 0.24, 0.05, 16);
        earGeo.rotateZ(Math.PI / 2);

        // Left ear
        const leftEar = new THREE.Mesh(earGeo, furMaterial);
        leftEar.position.set(0.5, 0.82, 0.28);
        leftEar.rotation.y = 0.2;
        leftEar.rotation.z = -0.2;
        this.mesh.add(leftEar);

        const innerEarLeft = new THREE.Mesh(
            new THREE.CylinderGeometry(0.16, 0.16, 0.06, 16).rotateZ(Math.PI / 2),
            innerEarMaterial
        );
        innerEarLeft.position.set(0.51, 0.82, 0.28);
        this.mesh.add(innerEarLeft);

        // Right ear
        const rightEar = new THREE.Mesh(earGeo, furMaterial);
        rightEar.position.set(0.5, 0.82, -0.28);
        rightEar.rotation.y = -0.2;
        rightEar.rotation.z = -0.2;
        this.mesh.add(rightEar);

        const innerEarRight = new THREE.Mesh(
            new THREE.CylinderGeometry(0.16, 0.16, 0.06, 16).rotateZ(Math.PI / 2),
            innerEarMaterial
        );
        innerEarRight.position.set(0.51, 0.82, -0.28);
        this.mesh.add(innerEarRight);

        // 4. Eyes (glossy black beads)
        const eyeGeo = new THREE.SphereGeometry(0.06, 12, 12);
        const leftEye = new THREE.Mesh(eyeGeo, eyeMaterial);
        leftEye.position.set(0.72, 0.62, 0.2);
        this.mesh.add(leftEye);

        const rightEye = new THREE.Mesh(eyeGeo, eyeMaterial);
        rightEye.position.set(0.72, 0.62, -0.2);
        this.mesh.add(rightEye);

        // 5. Sacred Bell Necklace (Lord Ganesha's blessing)
        const collarGeo = new THREE.TorusGeometry(0.42, 0.05, 12, 24);
        collarGeo.rotateY(Math.PI / 2);
        const collar = new THREE.Mesh(collarGeo, goldMaterial);
        collar.position.set(0.4, 0.48, 0);
        this.mesh.add(collar);

        const bellGeo = new THREE.SphereGeometry(0.09, 12, 12);
        this.bell = new THREE.Mesh(bellGeo, goldMaterial);
        this.bell.position.set(0.55, 0.28, 0);
        this.mesh.add(this.bell);

        // 6. Tail (curved slender tail trailing behind)
        const curve = new THREE.QuadraticBezierCurve3(
            new THREE.Vector3(-0.6, 0.35, 0),
            new THREE.Vector3(-1.1, 0.6, 0.2),
            new THREE.Vector3(-1.4, 0.8, -0.1)
        );
        const tailGeo = new THREE.TubeGeometry(curve, 16, 0.04, 8, false);
        this.tail = new THREE.Mesh(tailGeo, innerEarMaterial);
        this.mesh.add(this.tail);

        // 7. Soft ground shadow disc
        const shadowGeo = new THREE.CircleGeometry(0.65, 24);
        shadowGeo.rotateX(-Math.PI / 2);
        const shadowMat = new THREE.MeshBasicMaterial({
            color: 0x000000,
            transparent: true,
            opacity: 0.35
        });
        const shadow = new THREE.Mesh(shadowGeo, shadowMat);
        shadow.position.y = 0.02;
        this.mesh.add(shadow);
    }

    resetPosition() {
        this.mesh.position.set(0, 0.35, 5.5);
        this.mesh.rotation.y = -Math.PI / 2; // Facing north towards pandal
        this.facingAngle = -Math.PI / 2;
    }

    update(keys, delta, time) {
        let dx = 0;
        let dz = 0;

        if (keys["w"] || keys["arrowup"]) dz -= 1;
        if (keys["s"] || keys["arrowdown"]) dz += 1;
        if (keys["a"] || keys["arrowleft"]) dx -= 1;
        if (keys["d"] || keys["arrowright"]) dx += 1;

        if (dx !== 0 || dz !== 0) {
            this.isMoving = true;
            // Normalize direction
            const len = Math.hypot(dx, dz);
            dx /= len;
            dz /= len;

            this.mesh.position.x += dx * this.speed;
            this.mesh.position.z += dz * this.speed;

            // Clamping within festival square
            this.mesh.position.x = THREE.MathUtils.clamp(
                this.mesh.position.x,
                this.bounds.minX,
                this.bounds.maxX
            );
            this.mesh.position.z = THREE.MathUtils.clamp(
                this.mesh.position.z,
                this.bounds.minZ,
                this.bounds.maxZ
            );

            // Target facing rotation
            const targetAngle = Math.atan2(-dz, dx);
            // Smooth rotation slerp
            let diff = targetAngle - this.facingAngle;
            while (diff < -Math.PI) diff += Math.PI * 2;
            while (diff > Math.PI) diff -= Math.PI * 2;
            this.facingAngle += diff * 0.2;
            this.mesh.rotation.y = this.facingAngle;

            // Run bobbing animation
            this.mesh.position.y = 0.35 + Math.abs(Math.sin(time * 16)) * 0.08;
            this.mesh.rotation.z = Math.sin(time * 16) * 0.05;
        } else {
            this.isMoving = false;
            // Idle breathing animation
            this.mesh.position.y = 0.35 + Math.sin(time * 3) * 0.02;
            this.mesh.rotation.z = 0;
        }
    }

    get position() {
        return this.mesh.position;
    }
}
