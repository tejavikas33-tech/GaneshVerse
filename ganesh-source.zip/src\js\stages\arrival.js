/**
 * Stage 3: Ganesha Arrival
 * Cinematic transportation from workshop to the central pandal:
 * Devotees line the street, conch shells herald the arrival, dholak beats pulse,
 * camera glides along the street, flower petals shower down, and Ganesha is enthroned.
 */
import * as THREE from "three";
import gsap from "gsap";
import { gameState } from "../gameState.js";
import { audioSystem } from "../systems/audio.js";

export class GaneshaArrivalStage {
    constructor(game) {
        this.game = game;
        this.world = game.world;
        this.camera = game.camera;
        this.ui = game.ui;
        this.particles = game.particles;
        this.crowd = [];
    }

    start() {
        this.ui.updateHUD({
            stageNum: 3,
            stageName: "GANESHA ARRIVAL",
            objective: "Witness the sacred arrival and divine unveiling of Lord Ganesha.",
            score: gameState.score,
            chanda: gameState.chanda,
            progress: "Arrival Procession"
        });

        this.playArrivalCinematic();
    }

    playArrivalCinematic() {
        // Place Mushika leading the way at the pandal entrance
        this.game.player.mesh.position.set(0, 0.35, 1.8);
        this.game.player.mesh.rotation.y = -Math.PI / 2;

        // Spawn welcoming crowd along boulevard
        this.spawnStreetCrowd();

        // Atmospheric lighting transition to twilight
        gsap.to(this.world.ambient, { intensity: 1.0, duration: 2.0 });
        gsap.to(this.world.sunMoon, { intensity: 1.2, duration: 2.0 });

        // Sacred conch herald
        audioSystem.playConchCall();

        // Dholak beat rhythm
        for (let i = 0; i < 8; i++) {
            setTimeout(() => {
                audioSystem.playDholakBeat(i % 2 === 0 ? "bass" : "snap");
            }, 600 + i * 400);
        }

        // Camera gliding from street to pandal altar
        this.camera.position.set(0, 5.0, 14.0);
        gsap.to(this.camera.position, {
            x: 0,
            y: 3.8,
            z: 2.5,
            duration: 5.5,
            ease: "power2.inOut",
            onUpdate: () => {
                this.camera.lookAt(0, 2.8, -4.5);
            }
        });

        // Petal showers
        setTimeout(() => {
            audioSystem.playTempleBell(0.9);
            audioSystem.playTempleBell(1.15);

            for (let i = 0; i < 8; i++) {
                setTimeout(() => {
                    this.particles.createFirework(
                        (Math.random() - 0.5) * 8,
                        8.0 + Math.random() * 2,
                        -4.5 + (Math.random() - 0.5) * 4,
                        0xffd166
                    );
                }, i * 350);
            }
        }, 2200);

        // Climax: Divine Unveiling
        setTimeout(() => {
            gsap.to(this.world.altarSpot, { intensity: 7.5, duration: 1.5 });
            gsap.to(this.world.ambient, { intensity: 2.2, duration: 1.5 });

            audioSystem.playTempleBell(1.3);
            audioSystem.playDholakBeat("bass");

            this.world.revealGanesha(() => {
                this.particles.burstSparkles(0, 3.5, -4.5, 70);
                this.particles.burstSparkles(-1.8, 3.5, -4.5, 40);
                this.particles.burstSparkles(1.8, 3.5, -4.5, 40);

                gameState.addScore(150);
                this.showArrivalBanner();
            });
        }, 5500);
    }

    spawnStreetCrowd() {
        const positions = [
            [-3.2, 3.5], [3.2, 3.5],
            [-4.2, 6.0], [4.2, 6.0],
            [-3.5, 8.5], [3.5, 8.5],
            [-2.5, 0.8], [2.5, 0.8]
        ];

        const colors = [0x2b59c3, 0xc9184a, 0x38b000, 0x9d4edd, 0xf3c05b, 0xff7b00];

        positions.forEach(([cx, cz], i) => {
            const dev = new THREE.Group();
            const body = new THREE.Mesh(
                new THREE.CylinderGeometry(0.32, 0.45, 1.25, 16),
                new THREE.MeshStandardMaterial({ color: colors[i % colors.length], roughness: 0.7 })
            );
            body.position.y = 0.62;
            body.castShadow = true;
            dev.add(body);

            const head = new THREE.Mesh(
                new THREE.SphereGeometry(0.26, 16, 16),
                new THREE.MeshStandardMaterial({ color: 0xcc8e66, roughness: 0.8 })
            );
            head.position.y = 1.38;
            dev.add(head);

            dev.position.set(cx, 0, cz);
            dev.lookAt(0, 1.5, -4.5);
            this.game.scene.add(dev);
            this.crowd.push(dev);
        });
    }

    showArrivalBanner() {
        const overlay = document.createElement("div");
        overlay.id = "arrival-banner";
        overlay.className = "arrival-banner";
        overlay.innerHTML = `
            <div class="arrival-content">
                <span class="symbol">🕉️</span>
                <span class="sub">VIGHNAHARTA HAS ARRIVED</span>
                <h1>GANPATI BAPPA MORYA!</h1>
                <p>Lord Ganesha is enthroned on the sacred chowki. The neighborhood echoes with joyous prayers.</p>
                <div class="arrival-blessing">"Mangal Murti Morya, Pudhchya Varshi Lavkar Ya"</div>
                <button id="btn-proceed-pandal" class="btn-primary btn-large">
                    PREPARE PANDAL DECORATIONS ▶
                </button>
            </div>
        `;
        document.body.appendChild(overlay);

        document.getElementById("btn-proceed-pandal").onclick = () => {
            audioSystem.playClick();
            overlay.remove();
            this.finishStage();
        };
    }

    update(time, delta) {
        this.crowd.forEach((c, i) => {
            c.position.y = Math.sin(time * 2.5 + i) * 0.04;
        });
    }

    handleInteraction() {}

    finishStage() {
        gsap.to(this.camera.position, {
            x: 0,
            y: 7.5,
            z: 11.5,
            duration: 1.8,
            ease: "power2.out",
            onComplete: () => {
                this.cleanup();
                this.game.startStage(4);
            }
        });
    }

    cleanup() {
        // Keep crowd in the pandal for festival vibrancy
    }
}
